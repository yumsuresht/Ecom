using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CSF.Main.Notes
{
	/// <summary>
	/// Summary description for delete.
	/// </summary>
	public class delete : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			try
			{
				if (Request["noteID"] != null)
				{
					int noteID = Int32.Parse(Request["noteID"]);
				
					CSF.NotesDB deleteNote = new CSF.NotesDB();

					deleteNote.DeleteNote(Int32.Parse(Page.User.Identity.Name), noteID);
				
					Response.Redirect("index.aspx");
				}
			}
			catch
			{
				Response.Redirect("index.aspx");
			
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
