using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CSF.Main.Notes
{
	/// <summary>
	/// Summary description for sent.
	/// </summary>
	public class sent : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlGenericControl noteSendPass;
		protected System.Web.UI.HtmlControls.HtmlGenericControl noteSendFail;
	
		int noteVerify=0;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		bool noteStatus = false;

		private void Page_Load(object sender, System.EventArgs e)
		{
			displayNoteStatus();
		}

		/// <summary>
		/// Displays the appriopriate section depending on the status of the Note.
		/// QueryString value of 1 or 0 is passed to this page, 1 is pass, 0 is fail.
		/// On a failed note, have a button to go back.
		/// </summary>
		private void displayNoteStatus()
		{
			try
			{
				if (Request.QueryString["verify"] !=null)
				{
					noteVerify = Int32.Parse(Request["verify"]);
			
					

					if (noteVerify > 0)
					{
						noteStatus = true;
					}
					else
					{
						noteStatus = false;
					}
				}
			}
			catch
			{
				// Defualt to fail if problems
				noteVerify = 0;
				noteStatus = false;				
			}
							
			noteSendPass.Visible = noteStatus ? true : false;
			noteSendFail.Visible = noteStatus ? false : true;

			//areaLoggedIn.Visible = loggedIn ? true : false;
			//areaLoggedOut.Visible = loggedIn ? false : true;			
			
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
