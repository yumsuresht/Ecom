using System;

namespace CSF.Main.Question
{
	/// <summary>
	/// Summary description for post.
	/// </summary>
	public class post : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnSubmitReply;
		protected System.Web.UI.WebControls.TextBox tbReplyText;

		private void Page_Load(object sender, System.EventArgs e)
		{
		}

		public void btnSubmit_Click(object sender, EventArgs e)
		{
			if (Page.User.Identity.IsAuthenticated)
			{
				if(Request["QID"] != null)
				{
					int iQuestionID = Int32.Parse(Request["QID"]);

					// insert reply according to questionID, go back to replies
					CSF.Questions.InsertReply(iQuestionID, Int32.Parse(Page.User.Identity.Name), tbReplyText.Text);				
				
					Response.Redirect("replies.aspx?QID=" + iQuestionID);
			
				}
			}
			else
			{
				Response.Write("You must log-in to Post, please login and try again");
			}
		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
