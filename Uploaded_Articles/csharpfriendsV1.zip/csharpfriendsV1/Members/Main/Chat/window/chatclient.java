import java.awt.*;
import java.applet.*;
import java.net.*;
import java.lang.*;
import java.io.*;

// Chat Client Version 1.03 (July 10, 2000)
// Copyright 2000 by Michael Kohn

// Please read readme.txt file for copying/usage info

public class chatclient extends Applet implements Runnable
{
// Scrollbar vertScroll;
DisplayArea myDisplay;
TextArea myTextArea;
Thread myThread;
Socket mySocket;
InputStream myInputStream;
BufferedInputStream myBuffInput;
OutputStream myOutputStream;
Graphics gg;
TextField messageText,channelText,nameText;
Button LogButt;
int Online=0,debug=0;
Checkbox echoBox,hushBox;
Choice chanChoice,fontsizeChoice;
// Choice fontChoice,encodingChoice;
String YourName="";
int fontsize=13,allowanychannel=1,color=1;
Font myFont;
String font="monospaced";
int international=0;
String host;
int mouseMotion=0,barx,bary,barl,mouseValue;
Panel NorthPanel=new Panel();
String encodingString=null;

  public void init()
  {
  Panel SouthPanel=new Panel();
  Panel EastPanel=new Panel();
  Panel CenterPanel=new Panel();
  int r=0,eastitems;
  Label chanLabel;
  MediaTracker myTracker=new MediaTracker(this);
  int tracked=0;
  Color panelColor,panelforeColor;

    //System.out.println("Java Chat Applet version 1.02");
    //System.out.println("Copyright 2000 Michael Kohn");
    //System.out.println("http://nakenchat.naken.cc/");

    if (getParameter("debug")!=null)
    {
      if (getParameter("debug").equals("1")
           || getParameter("debug").toLowerCase().equals("true"))
      { debug=1; }
    }

    if (getParameter("international")!=null)
    {
      if (getParameter("international").equals("1")
           || getParameter("international").toLowerCase().equals("true"))
      { international=1; }
    }

    if (debug==1) System.out.println("In init()");

    if (getParameter("color")!=null)
    {
      if (getParameter("color").equals("0") 
	|| getParameter("color").toLowerCase().equals("false")) 
      { color=0; }
    }

    setLayout(new BorderLayout());
    NorthPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

    SouthPanel.setLayout(new BorderLayout());
    SouthPanel.add("West",new Label("Message:"));
    SouthPanel.add("Center",messageText=new TextField());

    if (!getParameter("channelbox").equals("0"))
    {
      NorthPanel.add(chanLabel=new Label("Channel:",Label.RIGHT));
      NorthPanel.add(chanChoice=new Choice());
      NorthPanel.add(channelText=new TextField("Main",14));
      chanChoice.addItem("---->");
      chanChoice.addItem("Main");
      r=1;
      while(getParameter("channel"+r)!=null)
      { chanChoice.addItem(getParameter("channel"+(r++))); }
    }

    if (!getParameter("namebox").equals("0"))
    {
      NorthPanel.add(new Label("Name:",Label.RIGHT));
      NorthPanel.add(nameText=new TextField("",15));
    }

    if (color==1)
    {
      CenterPanel.setLayout(new BorderLayout());
      CenterPanel.add("Center",myDisplay=new DisplayArea());

      if (getParameter("fgcolor")==null)
      { myDisplay.fgColor=Color.white; }
        else
      { myDisplay.fgColor=myDisplay.convColor(getParameter("fgcolor")); }

      if (getParameter("bgcolor")==null)
      { myDisplay.bgColor=Color.black; }
        else
      { myDisplay.bgColor=myDisplay.convColor(getParameter("bgcolor")); }

      if (getParameter("mscolor")==null)
      { myDisplay.msColor=new Color(0,190,0); }
        else
      { myDisplay.msColor=myDisplay.convColor(getParameter("mscolor")); }

      if (getParameter("privcolor")==null)
      { myDisplay.privColor=new Color(0,0,255); }
        else
      { myDisplay.privColor=myDisplay.convColor(getParameter("privcolor")); }

      if (getParameter("yellcolor")==null)
      { myDisplay.yellColor=new Color(255,0,0); }
        else
      { myDisplay.yellColor=myDisplay.convColor(getParameter("yellcolor")); }
/*
      barx=myDisplay.size().width-10;
      bary=myDisplay.location().y;
      barl=myDisplay.size().height;
*/
    }
      else
    {
      CenterPanel.add(myTextArea=new TextArea());
      myTextArea.setEditable(false);
    }

    if (getParameter("panelbackcolor")!=null)
    { panelColor=myDisplay.convColor(getParameter("panelbackcolor")); }
      else
    { panelColor=Color.lightGray; }

    if (getParameter("panelforecolor")!=null)
    { panelforeColor=myDisplay.convColor(getParameter("panelforecolor")); }
      else
    { panelforeColor=Color.black; }

    NorthPanel.setBackground(panelColor);
    SouthPanel.setBackground(panelColor);
    EastPanel.setBackground(panelColor);
    CenterPanel.setBackground(panelColor);

    NorthPanel.setForeground(panelforeColor);
    SouthPanel.setForeground(panelforeColor);
    EastPanel.setForeground(panelforeColor);
    CenterPanel.setForeground(panelforeColor);

    if (getParameter("scrollbarcolor")!=null)
    { myDisplay.scrollbarColor=myDisplay.convColor(getParameter("scrollbarcolor")); }

    eastitems=9;

    EastPanel.setLayout(new GridLayout(eastitems,1));

    if (getParameter("backgroundlogo")!=null)
    {
      myDisplay.backgroundImage=getImage(getDocumentBase(),getParameter("backgroundlogo"));
      myTracker.addImage(myDisplay.backgroundImage,tracked++);
      myDisplay.bgimage=1;
    }

    for(r=0; r<tracked; r++)
    {
      try { myTracker.waitForID(r); }
      catch (Exception e) { System.out.println("Error: "+e.toString()); }
    }

/*
    EastPanel.add(new Label("Font"));
    EastPanel.add(fontChoice=new Choice());
*/

    EastPanel.add(new Label("Font Size"));
    EastPanel.add(fontsizeChoice=new Choice());
    EastPanel.add(echoBox=new Checkbox("Private Echos",null,false));
    EastPanel.add(hushBox=new Checkbox("Hush Yells",null,false));


/*
    if (international==1)
    {
      EastPanel.add(encodingChoice=new Choice());
      // encodingChoice.addItem("ASCII");
      r=1;
      while(getParameter("encoding"+r)!=null)
      {
	encodingChoice.addItem(getParameter("encoding"+r));
	if (getParameter("encoding"+r).equals(getParameter("defaultencoding")))
	encodingChoice.select(getParameter("encoding"+r));
	r++;
      }
    }
*/

    if (international==1)
    {
      if (getParameter("defaultencoding")!=null)
      { encodingString=getParameter("defaultencoding"); }
        else
      { encodingString="ASCII"; }
    }

    EastPanel.add(new Button("Who is On"));
    EastPanel.add(new Button("Finger"));
    EastPanel.add(new Button("List Channels"));
    EastPanel.add(new Button("Help"));
    EastPanel.add(LogButt=new Button("Logoff"));

/*
    fontChoice.addItem("Dialog");
    fontChoice.addItem("DialogInput");
    fontChoice.addItem("Helvetica");
    fontChoice.addItem("TimesRoman");
    fontChoice.addItem("Courier");
    fontChoice.addItem("Serif");
    fontChoice.addItem("SansSerif");
    fontChoice.addItem("Monospaced");
*/

    for (r=6; r<20; r++) { fontsizeChoice.addItem(""+r); }


    if (!getParameter("bottombar").equals("0")) add("South",SouthPanel);
    if (!getParameter("channelbox").equals("0") || 
        !getParameter("namebox").equals("0"))
    { add("North",NorthPanel); }
    if (!getParameter("rightbar").equals("0")) add("East",EastPanel);
    add("Center",CenterPanel);

    if (color==0)
    {
      CenterPanel.add(myTextArea=new TextArea());
      myTextArea.resize(CenterPanel.size().width,CenterPanel.size().height);
      myTextArea.setEditable(false);
    }

    if (getParameter("allowanychannel")!=null)
    {
      if (getParameter("allowanychannel").equals("0") 
	|| getParameter("allowanychannel").toLowerCase().equals("false")) 
      { allowanychannel=0; }
    }

    if (getParameter("fontsize")!=null)
    {
      if (color==1)
      { myDisplay.fontsize=Integer.parseInt(getParameter("fontsize")); }
	else
      { fontsize=Integer.parseInt(getParameter("fontsize")); }
    }
      else
    { if (color==1) myDisplay.fontsize=13; }

    if (getParameter("font")!=null)
    {
      if (color==1) 
      { myDisplay.font=getParameter("font"); }
	else
      { font=getParameter("font"); }
    }
      else
    { if (color==1) myDisplay.font="Dialog"; }

    if (color==1)
    {
      myDisplay.setup();
      gg=myDisplay.getGraphics();
    }
      else
    {
      myFont=new Font(font,0,fontsize);
      myTextArea.setFont(myFont);
    }

    if (color==1)
    {
//      fontChoice.select(myDisplay.font);
      fontsizeChoice.select(""+myDisplay.fontsize);
    }
      else
    {
//      fontChoice.select(font);
      fontsizeChoice.select(""+fontsize);
    }


    if (debug==1) System.out.println("Leaving init()");
  }

  public void start()
  {
  int l;

    barx=myDisplay.size().width-10;
    // bary=myDisplay.location().y;
    bary=NorthPanel.size().height;
    barl=myDisplay.size().height;

    if (debug==1) System.out.println("In start()");

    l=logon();
    if (l==0)
    { 
      myThread=new Thread(this);
      myThread.start();
    }
  }

  public int logon()
  {
    if (debug==1) System.out.println("In logon()");
    try 
    {
      host=getCodeBase().getHost();

      if (getParameter("port")==null)
      { mySocket=new Socket(host,6666); }
	else
      { mySocket=new Socket(host,Integer.parseInt(getParameter("port"))); }

      myInputStream=mySocket.getInputStream(); 
      myBuffInput=new BufferedInputStream(myInputStream,2048);
      myOutputStream=mySocket.getOutputStream(); 
      Online=1;

      if (getParameter("defaultchannel")!=null)
      {
        try 
        { sendtext(".c"+getParameter("defaultchannel")); }
        catch (Exception e) {}
        channelText.setText(getParameter("defaultchannel"));
      }
    }
    catch (Exception e) { Online=0; }

    if (debug==1) System.out.println("Exiting logon(): "+Online);

    if (Online==1) return 0;

    return 1;
  }

  public void run()
  {
  byte[] in=new byte[2048];
  int r,c=0;
  String myString="";
  String inString="";

    if (debug==1) System.out.println("In run()");

    if (Online==1)
    { 
      if (getParameter("YourName")!=null)
      {
        if (!getParameter("namebox").equals("0"))
        { nameText.setText(getParameter("YourName")); }

        try 
        { sendtext(".n"+getParameter("YourName")); }
        catch (Exception e) {}
        YourName=getParameter("YourName");
      }

      try 
      { sendtext(".e"); }
      catch (Exception e) {}
    }

    while(true)
    {
      if (Online==1)
      {
        try { c=myBuffInput.read(in,0,2048); }
        catch (Exception e)
	{ System.out.println("Error: "+e.toString()); if (Online==1) Online=0; }

        if (c<=0)
        { Online=0; System.out.println("Death "+c);}

        if (international==1)
	{
	  // try { inString=new String(in,0,c,encodingChoice.getSelectedItem()); }
	  try { inString=new String(in,0,c,encodingString); }
	  catch (Exception e) { System.out.println("Error: "+e.toString()); }
	}

        for(r=0; r<c; r++)
        {
          if (in[r]!='\n' && in[r]!='\r') 
          {
	    if (international==1)
	    { myString+=""+inString.charAt(r); }
	      else
            { myString+=""+(char)in[r]; }
	  }
            else
          {
	    if (myString.length()>0)
/*
	    if (myString.charAt(0)=='<' && beepsBox.getState())
	    { paged.play(); }

	    if (international==0)
	    if (myString.startsWith(">> Someone just logged on") && logonbeepsBox.getState())
	    { logon.play(); }
*/

	    if (color==1)
	    {
              myDisplay.AddText(myString);
              myDisplay.paint(gg);
	    }
	      else
	    { myTextArea.appendText(myString+"\n"); }

    	    if (r+1<c && (in[r+1]=='\r' || in[r+1]=='\n')) r++;
            myString="";
          }
        } 
      }
        else
      if (Online==-1)
      {
	logon();
        // try { myOutputStream.write(convb(".n"+nameText.getText()+"\n")); }
	// catch (Exception ex) {}
      }
	else
      {
         if (color==1) 
	 { myDisplay.AddText(">> Connection closed by foreign host."); }
	   else
	 { myTextArea.appendText(">> Connection closed by foreign host.\n"); }
         LogButt.setLabel("Log On");
         try { mySocket.close(); }
	 catch (Exception e) { System.out.println("Socket: "+e.toString()); } 
         myThread.suspend();
      }      
    }
  }

  public boolean mouseDown(Event evt, int x, int y)
  {

    if ((x>barx && x<barx+myDisplay.scrollbarSize) &&
        (y>bary && y<bary+barl))
    {
      if (y-bary<(myDisplay.myBar_buffered-myDisplay.myBar_value)*2)
      {
        myDisplay.myBar_value+=myDisplay.lines;

        // if (myDisplay.myBar_value<0) myDisplay.myBar_value=0;

        if (myDisplay.myBar_value>=myDisplay.myBar_buffered-1) 
        { myDisplay.myBar_value=myDisplay.myBar_buffered-1; }

        myDisplay.paint(gg);
      } 
        else
      if (y-bary>(barl-(myDisplay.myBar_value*2)))
      {
        myDisplay.myBar_value-=myDisplay.lines;

        if (myDisplay.myBar_value<0) myDisplay.myBar_value=0;

        // if (myDisplay.myBar_value>=myDisplay.myBar_buffered-1) 
        // { myDisplay.myBar_value=myDisplay.myBar_buffered-1; }

        myDisplay.paint(gg);
      } 
        else
      {
        mouseMotion=y;
        mouseValue=myDisplay.myBar_value;
      }
    }

    return true;
  }

  public boolean mouseDrag(Event evt, int x, int y)
  {
  int l;

    if (mouseMotion!=0)
    {
      if (y-bary>0 && y-bary<barl)
      {
        l=(int)((mouseMotion-y)/2);
        myDisplay.myBar_value=mouseValue+l;

        if (myDisplay.myBar_value<0)
        { myDisplay.myBar_value=0; }

        if (myDisplay.myBar_value>=myDisplay.myBar_buffered-1) 
        { myDisplay.myBar_value=myDisplay.myBar_buffered-1; }

        myDisplay.paint(gg);
      }
    }

    return true;
  }

  public boolean mouseUp(Event evt, int x, int y)
  {
    mouseMotion=0;

    return true;
  }



  public boolean action(Event e, Object o)
  {
  String obj;
  String message;

    obj=o.toString();
    if (debug==1)
    {
      System.out.println("In action(): "+e.target.toString());
    }

    try 
    {
      if (e.target==channelText && allowanychannel==1)
      { 
        sendtext(".c "+channelText.getText());
        if (channelText.getText().equals("0")) channelText.setText("Main");
          else
        if (channelText.getText().equals("main")) channelText.setText("Main");
          else
        if (channelText.getText().equals("1"))
            channelText.setText("Masquerade");
          else
        if (channelText.getText().equals("masquerade"))
            channelText.setText("Masquerade");
      }
        else
      if (e.target==messageText)
      { 
        message=messageText.getText();

        if (debug==1) System.out.println("Message: "+message);

        if (message.startsWith(".hu"))
        { hushBox.setState(!hushBox.getState());  }
        /*
          else
        
        if (message.startsWith(".n"))
        { 
          if (!getParameter("namebox").equals("0"))
          { nameText.setText(message.substring(2)); }
          */
        }
        
          else
        if (message.startsWith(".c") && allowanychannel==0)
	{
	  message=".Q";
	}
          else
        if (message.startsWith(".b"))
	{
          if (color==1) 
	  { myDisplay.AddText(">> Applet sound disabled."); }
	    else
	  { myTextArea.appendText(">> Applet sound disabled.\n"); }
	}
	  else
        if (message.startsWith(".e"))
        { echoBox.setState(!echoBox.getState());  }


/*  all i can say is.. what the hell was i thinking with this?? SHEEESH!!!
          else
        if (message.startsWith(".h"))
        {
          message="";
          if (color==1) 
	  { myDisplay.AddText(">> This is automatic here."); }
	    else
	  { myTextArea.appendText(">> This is automatic here.\n"); }
        }
*/

        sendtext(message);
        messageText.setText("");
      }
        else
      if (e.target==nameText)
      { 
        if (!nameText.getText().equals(YourName))
          sendtext(".n"+nameText.getText());
        YourName=nameText.getText();
      }
        else
      if (e.target==chanChoice)
      {
        if (chanChoice.getSelectedIndex()!=0)
        {
          sendtext(".c"+chanChoice.getSelectedItem()); 
          channelText.setText(chanChoice.getSelectedItem());
          chanChoice.select(0);
        }
      }
        else
      if (obj.equals("Who is On")) 
      { sendtext(".w"); }
        else
      if (obj.equals("Finger"))
      { sendtext(".f"); }
        else
      if (obj.equals("List Channels"))
      { sendtext(".a"); }
        else
      if (obj.equals("Help"))
      { sendtext(".he"); }
        else
      if (obj.equals("Logoff"))
      { 
        LogButt.setLabel("Log On");
        sendtext(".q");
        myThread.sleep(1000);
        try { mySocket.close(); } catch (Exception ex) {} 
        Online=0;
        myThread.suspend();
      }
        else
      if (obj.equals("Log On"))
      {
        LogButt.setLabel("Logoff");
        channelText.setText("Main");

        if (!getParameter("namebox").equals("0"))
        { nameText.setText(""); }

        hushBox.setState(false); 
        echoBox.setState(false); 
        YourName="";
	Online=-1;
        myThread.resume();
      }
        else
      if (e.target.toString().indexOf("Hush Yells")>=0)
      { sendtext(".hu"); }
        else
      if (e.target.toString().indexOf("Private Echos")>=0)
      { sendtext(".e"); }
        else
      if (e.target.toString().indexOf("Back To Main")>=0)
      {
        sendtext(".c0");
        channelText.setText("Main");
      }
        else
      if (e.target==fontsizeChoice)
      {
	if (color==1)
	{
	  myDisplay.fontsize=Integer.parseInt(fontsizeChoice.getSelectedItem());
	  myDisplay.recalc();
          myDisplay.paint(gg);
	}
	  else
	{
	  fontsize=Integer.parseInt(fontsizeChoice.getSelectedItem());
	  myFont=new Font(font,0,fontsize);
	  myTextArea.setFont(myFont);
	}
      }
/*
	else
      if (e.target==fontChoice)
      {
	if (color==1)
	{
	  myDisplay.font=fontChoice.getSelectedItem();
	  myDisplay.recalc();
          myDisplay.paint(gg);
	}
	  else
	{
	  font=fontChoice.getSelectedItem();
	  myFont=new Font(font,0,fontsize);
	  myTextArea.setFont(myFont);
	}
      }
*/
    }
    catch (Exception ex) { System.out.println("Problem: "+ex.toString()); }
 
    if (debug==1) System.out.println("Exit action()");
    return false;
  }

  public void sendtext(String myString)
  {
    try
    {
      myOutputStream.write(convb(myString+"\n"),0,myString.length()+1);
    }
    catch (Exception e) { System.out.println("Error: "+e.toString()); }
  }

  byte[] convb(String myString)
  {
  byte[] myBytes=new byte[2048];
  int r;
  
    if (international==0)
    {
      for(r=0; r<myString.length(); r++)
      {
        if (myString.charAt(r)!=0) myBytes[r]=(byte)myString.charAt(r);
      } 
      myBytes[r]=0;
    }
      else
    {
      try
      // { myBytes=myString.getBytes(encodingChoice.getSelectedItem()); }
      { myBytes=myString.getBytes(encodingString); }
      catch (Exception e) { System.out.println("Error: "+e.toString()); }
    }

    return myBytes;
  } 

  public void stop()
  {
    if (debug==1) System.out.println("In stop()");
    try { mySocket.close(); } catch (Exception e) {}
    myThread.stop();
  }
}

class DisplayArea extends Canvas 
{
int max=100,beeps=0;
Color bgColor,fgColor,msColor,privColor,yellColor;
String[] Buffer;
byte[] BFlags;
String Line;
int topptr=0,botptr=0,bsize=0,scrollval,lastbsize=0;
int lines,columns,spacin,spacing,scrollbarSize;
Font myFont;
FontMetrics fm;
Graphics gg;
Image OffScreen;
int myBar_value;
int myBar_buffered;
int fontsize,bgimage=0;
String font;
Image backgroundImage=null;
Panel logoPanel;
Color scrollbarColor;

  public DisplayArea()
  {
/*
    if (getParameter("fgcolor")==null)
    { fgColor=Color.white; }
      else
    { fgColor=convColor(getParameter("fgcolor")); }

    if (getParameter("bgcolor")==null)
    { bgColor=Color.black; }
      else
    { bgColor=convColor(getParameter("bgcolor")); }

    if (getParameter("mscolor")==null)
    { msColor=new Color(0,190,0); }
      else
    { msColor=convColor(getParameter("mscolor")); }

    if (getParameter("privcolor")==null)
    { privColor=new Color(0,0,255); }
      else
    { privColor=convColor(getParameter("privcolor")); }

    if (getParameter("yellcolor")==null)
    { yellColor=new Color(255,0,0); }
      else
    { yellColor=convColor(getParameter("yellcolor")); }
*/

    Buffer=new String[max];
    BFlags=new byte[max];

    scrollbarColor=Color.lightGray;
  }

  public void setup()
  {
  int r=0;

    gg=this.getGraphics();


    myFont=new Font(font,Font.BOLD,fontsize);
    gg.setFont(myFont);
/*
    fm=gg.getFontMetrics();
    while (fm.stringWidth("XXXXXX")!=fm.stringWidth("iiiiii") && r<5)
    { 
      myFont=new Font(fontlist[r],Font.BOLD,fontsize); 
      gg.setFont(myFont);
      font=fontlist[r];
      r++;
    }
    if (r==3) 
    {
      myFont=new Font(daFont,Font.BOLD,fontsize);
      gg.setFont(myFont);
      font=daFont;
    }
*/ 
    // lines=d.height/spacing;
    fm=gg.getFontMetrics();
    spacing=fm.getHeight();
    scrollbarSize=14;
    myBar_buffered=0;
    myBar_value=0;
  }

  public void recalc()
  {
  Dimension d;

    gg=OffScreen.getGraphics();
    myFont=new Font(font,Font.BOLD,fontsize);
    gg.setFont(myFont);
    fm=gg.getFontMetrics();
    spacing=fm.getHeight();
    d=this.size();
    lines=d.height/spacing;
    ScrollRecalc(1);
  }

  public void AddText(String myString)
  {
  Dimension d;
  int r,spc,last;
  byte sflag=0;

    d=this.size();
    if (myString.length()>0)
    {
      if (myString.charAt(0)=='>') sflag=1;
        else
      if (myString.charAt(0)=='<') 
      {
        sflag=2; 
        if (beeps!=0) System.out.println((char)7);
      }
        else
      if (myString.charAt(0)=='#') sflag=3;
        else
      if (myString.charAt(0)=='-') sflag=4;
    }
   
    while(myString.length()>0)
    {
      if (fm.stringWidth(myString)<d.width-scrollbarSize || sflag==4)
      { AddLine(myString,sflag); break; } 

      r=myString.length()-1;
      
      while(r>=0 && 
            fm.stringWidth(myString.substring(0,r))>d.width-scrollbarSize)
      { r--; }

      spc=0; last=0;

      while((spc=myString.indexOf(' ',spc+1))<r && spc>0) last=spc;
      if (last<=0) { last=r; }
      AddLine(myString.substring(0,last),sflag);
      myString=myString.substring(last,myString.length()).trim();
    }
  }

  public void AddLine(String myString,byte flags)
  {
    BFlags[topptr]=flags;
    Buffer[topptr++]=myString;
    if(topptr==max) topptr=0;

    ScrollRecalc(0);
  }

  public void ScrollRecalc(int i)
  {
/* recalculate scrollbar size */

/* max is maximum number of lines */
/* bsize the current number of text lines in buffer (including on screen) */
/* lastbsize the last bsize */
/* lines is the number of visible text lines on the screen */

    if (i==0 && bsize<max) bsize++;
    myBar_buffered=bsize-lines;
    if (myBar_buffered<0) myBar_buffered=0;
    myBar_value=0;
  }

  public void paint(Graphics ggReal)
  {
  Dimension d;
  int r,l;
  int ptr,offset;

    d=this.size();
    if (OffScreen==null)
    {
      OffScreen=createImage(d.width,d.height);
      gg=OffScreen.getGraphics();
    }
    
    gg.setColor(bgColor);
    gg.setFont(myFont);
    gg.fillRect(0,0,d.width,d.height);
    l=0;

    if (backgroundImage!=null)
    {
      gg.drawImage(backgroundImage,
                   (d.width/2)-(backgroundImage.getWidth(null)/2),
                   (d.height/2)-(backgroundImage.getHeight(null)/2),null);
    }

    lines=d.height/spacing;
    if (bsize<=lines) { offset=0; }
      else
    { 
      offset=myBar_value;
    }
    // myBar.setPageIncrement(lines);
    ptr=topptr-lines-offset;
    while (ptr<0) ptr=ptr+max;

    for (r=0; r<lines; r++)
    {
      if (ptr==topptr)
      { r=9000; }
        else
      {
        if (Buffer[ptr]!=null)
        {
          if (Buffer[ptr].length()>0)
          {
            if (BFlags[ptr]==1) { gg.setColor(msColor); }
              else
            if (BFlags[ptr]==2) { gg.setColor(privColor); }
              else
            if (BFlags[ptr]==3) { gg.setColor(yellColor); }
              else
            { gg.setColor(fgColor); } 
          }
            else
          { gg.setColor(fgColor); } 
          l=l+spacing;
          gg.drawString(Buffer[ptr],3,l);
        }
        if (++ptr==max) ptr=0;
      }
    }

    gg.setColor(Color.darkGray);
    gg.fillRect(d.width-scrollbarSize,0,scrollbarSize,d.height);
    gg.setColor(scrollbarColor);
    l=d.height-(myBar_buffered*2);
    gg.fillRect(d.width-scrollbarSize+2,((myBar_buffered-myBar_value)*2)+2,
              scrollbarSize-3,l-3);
              // scrollbarSize-3,d.height-(myBar_buffered-myBar_value)*2-3);
    ggReal.drawImage(OffScreen,0,0,null);

  }

  public int convHex(String DaHex)
  {
  char m,l;
  byte msb,lsb;

    DaHex=DaHex.toLowerCase();
    m=DaHex.charAt(0);
    l=DaHex.charAt(1);
    if (m>='0' && m<='9') { msb=(byte)(m-'0'); }
      else
    if (m>='a' && m<='f') { msb=(byte)(m-'a'+10); }
      else
    { msb=0; }

    if (l>='0' && l<='9') { lsb=(byte)(l-'0'); }
      else
    if (l>='a' && l<='f') { lsb=(byte)(l-'a'+10); }
      else
    { lsb=0; }

    return msb*16+lsb;
  }

  public Color convColor(String DisColor)
  {
  int r,g,b;

    r=convHex(DisColor.substring(1,3));
    g=convHex(DisColor.substring(3,5));
    b=convHex(DisColor.substring(5,7));
    return new Color(r,g,b);
  }
}

