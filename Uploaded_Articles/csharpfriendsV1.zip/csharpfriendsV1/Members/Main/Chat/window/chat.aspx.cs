using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CSF.Main.Chat.window
{
	/// <summary>
	/// Summary description for chat.
	/// </summary>
	public class chat : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedIn;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedOut;

		public string szUserName = "";

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			ShowLoggedInArea();
		}

		// display different items if person is logged in or not
		private void ShowLoggedInArea()
		{
			// check to see if we have a sessionid(formsAuthentication)
			bool loggedIn = false;
			
			if (Page.User.Identity.IsAuthenticated)
			{
				//loggedIn = (context.User.Identity.Name != null) ? true : false;
				loggedIn = true;

				// UserName fed to chat server
				if (Request.Cookies["csf_szUserName"] != null) 
				{
					szUserName = Request.Cookies["csf_szUserName"].Value;
				}
				else
				{
					loggedIn = false; //no cookie, fail!
				}
			}

			// show or hide login buttons
			areaLoggedIn.Visible = loggedIn ? true : false;
			areaLoggedOut.Visible = loggedIn ? false : true;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
