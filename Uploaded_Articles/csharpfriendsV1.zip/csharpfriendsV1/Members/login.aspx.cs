using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

namespace CSF
{
	/// <summary>
	/// Summary description for login.
	/// </summary>
	public class login : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Message;  //failed login
		protected System.Web.UI.WebControls.TextBox userName;
		protected System.Web.UI.WebControls.TextBox password;

		protected System.Web.UI.WebControls.CheckBox chkRememberPassword;

		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.Button LoginBtn;


		private void Page_Load(object sender, System.EventArgs e)
		{
			
		}

		public void LoginBtn_Click(Object sender, EventArgs e)
		{

			// Only attempt a login if all form fields on the page are valid
			if (Page.IsValid == true) 
			{

				// Attempt to Validate User Credentials using CustomersDB
				CSF.UsersDB user = new CSF.UsersDB();
				CSF.UserDetails myUser = user.Login(userName.Text, password.Text, CSF.Constants.PTS_LOGIN);

				if (myUser != null) 
				{

					
					// Cookie with User Name
					if (!chkRememberPassword.Checked)
					{
						// Store the user's fullname in a cookie for personalization purposes
						Response.Cookies["csf_szUserName"].Value = myUser.szUserName;
					}
					else
					{
						// Persist the cookie also up until 12:00AM since
						// we need to allow user to rec points for loggin in
						Response.Cookies["csf_szUserName"].Value = myUser.szUserName;
						Response.Cookies["csf_szUserName"].Expires = DateTime.Now + new TimeSpan(365,0,0,0);					
					}
										
					//FormsAuthentication.SetAuthCookie(myUser.userID.ToString(),false);
					FormsAuthentication.RedirectFromLoginPage(myUser.userID.ToString(),chkRememberPassword.Checked);
					
					
					
						
				}
				else 
				{
					Message.Text = "Login Failed!";					
				}

			}
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
