using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CSF
{
	/// <summary>
	/// Summary description for ad_redirect.
	/// </summary>
	public class ad_redirect : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			
			try
			{
				if(Request.Params["ADID"] != null)
				{			
					//Response.Write(CSF.Utils.AdClick(Int32.Parse(Request.Params["ADID"])));
				
					Response.Redirect("http://" + CSF.Utils.AdClick(Int32.Parse(Request.Params["ADID"])));			
					//Server.Transfer("http://" + csf.Utils.AdClick(Int32.Parse(Request.Params["ADID"])));			
				}
			}
			catch
			{
				Response.End();
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
