/*
function showProfile(memberAlias, memberNo) 
{ 
	var profileURL = "/Members/Main/User/index.aspx?szUN=" + memberAlias + "&userID=" + memberNo;
	window.open(profileURL,'profileWin','width=500,height=420,scrollbars=yes,resizable=yes');
}
*/

function showProfile(memberAlias, memberNo, RootURL) 
{ 
	var profileURL = RootURL + "/Members/Main/User/index.aspx?szUN=" + memberAlias + "&userID=" + memberNo;
	window.open(profileURL,'profileWin','width=500,height=420,scrollbars=yes,resizable=yes');
}

function showPollResults() 
{ 
	window.open("../modules/polls/results.aspx",'pollWin','width=500,height=420,scrollbars=yes,resizable=yes');
}

function popupWindow(url) 
{
		var win = open(url,'','width=635,height=430,scrollbars=yes,menubar=true,resizable=yes');
}

function unsetAll(howMany)
{
	var i;
								
	i = 0;
	howMany = howMany + i - 1;
															
	for (i ; i < howMany+1; i++)
	{
		formCheck=eval( "document.Form1.noteID[i]");
		formCheck.checked=true
	}
}			

function setAll(howMany)
{
	var i;
	
	i = 0;
	howMany = howMany + i - 1;
											
	for (i ; i < howMany+1; i++)
	{
		formCheck=eval( "document.Form1.noteID[i]");
		formCheck.checked=false
	}
	
}

function openWindow( theURL, winName, features )
{
	winHandle = window.open( theURL, winName, features ) ;
}



function showSample(Alias) 
{ 
	var profileURL = "Run/" + Alias;
	window.open(profileURL,'profileWin','width=500,height=420,scrollbars=yes,resizable=yes');
}