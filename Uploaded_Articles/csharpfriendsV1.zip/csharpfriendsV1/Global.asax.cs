using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;

namespace CSF
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{
						
						
		}
 
		protected void Session_Start(Object sender, EventArgs e)
		{
		

		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{
			
		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{			
			
		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{

		}

		/// <summary>
		/// Email any untrapped errors with error details
		/// </summary>			
		private void Application_Error(object sender, System.EventArgs e) 
		{
			string strErrorMsg = "CSF Application Error\n\n";
						
			// Get the path of the page
			strErrorMsg += "Error in Path :" + Request.Path;

			// Get the QueryString along with the Virtual Path
			strErrorMsg += "\n\n Error Raw Url :" + Request.RawUrl;

			// Create an Exception object from the Last error that occurred on the server
			Exception myError =Server.GetLastError();

			// Get the error message
			strErrorMsg += "\n\nError Message :" + myError.Message;

			// Source of the message
			strErrorMsg += "\n\nError Source :" + myError.Source;

			// Stack Trace of the error
			strErrorMsg += "\n\nError Stack Trace :" + myError.StackTrace;

			// Method where the error occurred
			strErrorMsg += "\n\nError TargetSite :" + myError.TargetSite;
			
			// Email Error

			string strEmail = System.Configuration.ConfigurationSettings.AppSettings["AdminEmail"];

			if( "true" == System.Configuration.ConfigurationSettings.AppSettings["ReportErrors"].ToLower())
			{
				CSF.Utils.SendMail(strEmail,strEmail, "CSF Error", strErrorMsg);
			}
		
		}

		protected void Session_End(Object sender, EventArgs e)
		{

		}

		protected void Application_End(Object sender, EventArgs e)
		{

		}

			
		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
		}
		#endregion
	}
}

