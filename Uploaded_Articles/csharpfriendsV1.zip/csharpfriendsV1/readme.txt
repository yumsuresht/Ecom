===============================
CSharpFriends Community Engine Version 1.0
===============================
The following is a really neat application that allows you to instantly start a online community.  Visitors can register and create
their online profile for other memebers too see.  Members can post on forums, comment on articles and post their opinions in the Daily Question section.
There is also a online chat module but requires Java to be installed on the server.

You can view a live example at http://www.csharpfriends.com/SourceCode/csharpfriendsV1/

This application uses user controls which enables you to easily expand and customize this application.

Currently CSharpFriends is using a completely re-written source code base, its a much cleaner design using a more OOP approach.
I am considering releasing the code for v2.0 but at the moment its a work-in-progress so you'll have to wait!

Installation
============

1.  Create a folder in c:/inetpub/wwwroot named CSharpFriendsV1.  Unzip the csharpfriendsv1.zip file and copy all the extracted files (all the files inside the CSharpFriendsV1 you just unzipped) to the CSharpFriendsV1 folder you just created.

2. Make sure your web application is configured as an application.In Internet Services Manager right-click on the folder, select Properties, and ensure "Application Name" is *not* grayed. If it is, click Create.
   (make sure you add index.aspx as a default in the Documents Tab of your CSharpfriendsV1 IIS/wwwroot folder)

3. Copy all directories and files into your web application.

4. Database configuration
	- create a Database in SQLServer using Enterprise Manager.  Name the database: csharpfriends
	- look in the /Database folder for sql scripts.  Open and cut-and-paste the database.sql into query analyzer
	  and execute the script (make sure the csharpfriends database is selected, use the commaind 'use csharpfriends' if necessary)
	- open and cut-and-paste the sample_data.sql script and execute it in query analyzer also

5. Recompile your code whenever you make modifications or you are using asp.net 1.1 (see below for instructions)

6. Open a browser to test the application, e.g. http://localhost/csharpfriends/

7. A Default user has been created: login is 'Admin' and password is 'admin'.



Opening project in Visual Studios
==================================
(Note:  You will need VS.NET 2003 to open the project.  If you have 2002 then you can manually create an empty web
project and then copy and past the files to the project.  Click on 'Show all files' and manually 'include in project' all the files.  Make sure you delete
all the VS.NET related files before doing this.)
1.  After creating the IIS directory etc, open up visual studios and click on Open.
2.  Select 'Open Project From Web'
3.  Locate the csharpfriends folder and click on the csharpfriends project file.


Compilation
============

1. Compile the application with the following command.  Ensure 'csc' is setup in your PATH.
(Go to Systems, Add C:\WINDOWS\Microsoft.NET\Framework\v1.0.3705 to your path in Environmental Variables section so you can use the csc command from anywhere in your command prompts)

To compile: 

  Batch File
  1. Go the CSharpFriends directory and run the compile.bat file in command prompt:
	example:
	c:\inetpub\wwwroot\csharpfriends\compile.bat   

  Manual
  1.  Go to the c:\inetpub\wwwroot directory in command prompt
  2.  csc /t:library /out:bin/CSF.dll /recurse:*.cs /r:System.dll /r:System.Web.dll /r:System.Xml.dll /r:System.Data.dll


NOTE: - If any of your drive letters are not c: you will have to modify it as necessary.
	  - REMOVE / Relocate the /Database folder and the compile.bat scripts to a directory that is not accessible via the web	

Admin Section
=============

1. TODO!  There is currently no administration section.  All content is added using sql scripts.  I will add these scripts 
   to the /Database folder so you can manually enter the content.


OUTPUT Cache
==============

Most pages are cached.  During development you might want to remove the caches so you can view your modifications immediately (its annoying
to develop and not be able to view your changes).

LIVE Example
============

View a live demo of the site at http://www.csharpfriends.com/SourceCode/csharpfriendsV1/


Changing the DotNetNotes name
==============================

1.  Modify the constants.cs files strRootURL variable along with the database directory 
2.  Modify the web.config so the login & error pages redirects to the correct folder

Support
========

Although this is a sample application (which I don't intend on supporting really), you can contact me at admin@csharpfriends.com if you run into
major problems.

Enjoy!



Trouble Shooting
=================

Question:  I tried to access the page http://localhost/csharpfriends/ and I got this error:

		"Parser Error Message: It is an error to use a section registered as allowDefinition='MachineToApplication' beyond application level. This error can be caused by a virtual directory not being configured as an application in IIS."

Solution:  You have not created a Application directory in IIS.  See step#1 in the installation section above.

Question:  I keep getting a database error of some kind.

Solution:  Make sure your web.config file has the correct ConnectionString information.  If you created a different user to access the
           database you will have to adject the web.config also.