using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace CSF
{
	/// <summary>
	/// Summary description for Utils.
	/// </summary>
	public class Utils
	{
		public static string AdClick(int ADID)
		{
			SqlDataReader reader = null;
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@ADID", SqlDbType.Int, 4, ADID)				
			};

			// run the stored procedure
			data.RunProc("procPutAdClick", prams, out reader);

			//if returns null, go to csf page
			while (reader.Read())
			{
				return reader.GetString(0);
			}
			//return (reader.IsDBNull(0) ? "index.aspx" : reader.GetString(0));
			return "index.aspx";
						
		}
		
		/// <summary>
		/// saves stats upon application on end event
		/// </summary>
		/// <param name="dtCreated"></param>
		/// <param name="activeUsers"></param>
		/// <param name="usersToday"></param>
		/// <param name="pagesToday"></param>
		/// <param name="bannerTop"></param>
		/// <param name="bannerSky"></param>
		public static void SetStatistics(System.DateTime dtCreated,int activeUsers, int usersToday, int pagesToday, int bannerTop, int bannerSky, int bannerSquare, int bannerButton)
		{
			Database data = new Database(); 

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@dtCreated", SqlDbType.DateTime, 8, dtCreated),
				data.MakeInParam("@activeUsers", SqlDbType.Int, 4, activeUsers),
				data.MakeInParam("@usersToday", SqlDbType.Int, 4, usersToday),
				data.MakeInParam("@pagesToday", SqlDbType.Int, 4, pagesToday),
				data.MakeInParam("@bannerTop", SqlDbType.Int, 4, bannerTop),
				data.MakeInParam("@bannerSky", SqlDbType.Int, 4, bannerSky),
				data.MakeInParam("@bannerSquare", SqlDbType.Int, 4, bannerSquare),
				data.MakeInParam("@bannerButton", SqlDbType.Int, 4, bannerButton)
			};

			// run the stored procedure
			data.RunProc("procPutStatistics", prams);
									
		}

		/// <summary>
		/// gets stats saved on application end
		/// </summary>
		/// <param name="ADID"></param>
		/// <returns></returns>
		public static void GetStatistics()
		{
			SqlDataReader reader = null;
			
			Database data = new Database(); 
		

			// run the stored procedure
			data.RunProc("procGetStatistics", out reader);

			//if returns null, go to csf page
			while (reader.Read())
			{
				
				System.Web.HttpContext.Current.Application["dtCreated"] = (reader.IsDBNull(2) ? System.DateTime.Today : reader.GetDateTime(2));
				System.Web.HttpContext.Current.Application["ActiveUsers"] = (reader.IsDBNull(3) ? 0 : reader.GetInt32(3));
				System.Web.HttpContext.Current.Application["UsersToday"] = (reader.IsDBNull(4) ? 0 : reader.GetInt32(4));				
				System.Web.HttpContext.Current.Application["PagesToday"] = (reader.IsDBNull(5) ? 1 : reader.GetInt32(5));
				System.Web.HttpContext.Current.Application["BannerTop"] = (reader.IsDBNull(6) ? 0 : reader.GetInt32(6));
				System.Web.HttpContext.Current.Application["BannerSky"] = (reader.IsDBNull(7) ? 0 : reader.GetInt32(7));				
				System.Web.HttpContext.Current.Application["BannerSquare"] = (reader.IsDBNull(7) ? 0 : reader.GetInt32(8));				
				System.Web.HttpContext.Current.Application["BannerButton"] = (reader.IsDBNull(7) ? 0 : reader.GetInt32(9));				
										
			}
			
						
		}

		public static void SendMail(string strTo, string strFrom, string strSubject, string strBody)
		{
			System.Web.Mail.MailMessage mail = new System.Web.Mail.MailMessage();

			mail.To =	strTo;
			mail.From = strFrom;
			mail.Subject = strSubject;
			mail.Body = strBody;
			mail.BodyFormat = System.Web.Mail.MailFormat.Text;

			System.Web.Mail.SmtpMail.Send(mail);
		
		}

		/// <summary>
		/// Send admin email
		/// </summary>
		/// <param name="szBody"></param>
		public static void EmailMe(string strSubject, string strBody)
		{
			try
			{	
				System.Web.Mail.MailMessage mm = new System.Web.Mail.MailMessage();
				mm.From = System.Configuration.ConfigurationSettings.AppSettings["AdminEmail"];
				mm.To = System.Configuration.ConfigurationSettings.AppSettings["AdminEmail"];
				mm.Subject = "[csharpfriends.com]" + strSubject;
				mm.Body = strBody;
				mm.BodyFormat = System.Web.Mail.MailFormat.Text;

				System.Web.Mail.SmtpMail.Send(mm);
			}
			catch
			{
				//nothing
			}
		
		}

		/// <summary>
		/// Write info to file, specify path also, ensure asp.net account
		/// has write privledges, explore-right-clic, prop,etc
		/// </summary>
		/// <param name="szData"></param>
		public static void WriteToFile(string szData, string szFilePath)
		{
			//Write to file, Append (true)
			StreamWriter sw = new StreamWriter(szFilePath,true);
	
			//Write to a new line
			sw.WriteLine (szData);
	
			//Cleanup 
			sw.Close();
		
		}

		//read from file
		public static string ReadFromFile(string path, string fileName)
		{
			System.IO.StreamReader sr = System.IO.File.OpenText( path + "/" + fileName );
			String text = sr.ReadToEnd();
			sr.Close();
			return text;
		}

	}
}
