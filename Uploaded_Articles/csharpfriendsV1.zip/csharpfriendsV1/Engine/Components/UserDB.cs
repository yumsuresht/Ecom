using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CSF
{
	
	//structure to hold user's info
	public class UserDetails 
	{
		public int userID;
		public string szUserName;
	}

	/// <summary>
	/// Summary description for UsersDB.
	/// </summary>
	public class UsersDB
	{
		//*******************************************************
		//
		// CustomersDB.Login() Method <a name="Login"></a>
		//
		// The Login method validates a email/password pair
		// against credentials stored in the customers database.
		// If the email/password pair is valid, the method returns
		// the "CustomerId" number of the customer.  Otherwise
		// it will throw an exception.
		//
		// Other relevant sources:
		//     + <a href="CustomerLogin.htm" style="color:green">CustomerLogin Stored Procedure</a>
		//
		//*******************************************************

		public UserDetails Login (string szUserName, string szPassword, int PTS_LOGIN) 
		{

			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procDoLogin", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;

			// Add Parameters to SPROC
			SqlParameter parameterUserName = new SqlParameter("@szUserName", SqlDbType.VarChar, 15);
			parameterUserName.Value = szUserName;
			myCommand.Parameters.Add(parameterUserName);

			SqlParameter parameterPassword = new SqlParameter("@szPassword", SqlDbType.VarChar, 15);
			parameterPassword.Value = szPassword;
			myCommand.Parameters.Add(parameterPassword);

			SqlParameter parameterPTS_LOGIN = new SqlParameter("@PTS_LOGIN", SqlDbType.Int, 4);
			parameterPTS_LOGIN.Value = PTS_LOGIN;
			myCommand.Parameters.Add(parameterPTS_LOGIN);

			SqlParameter parameterUserID = new SqlParameter("@userID", SqlDbType.Int, 4);
			parameterUserID.Direction = ParameterDirection.Output;
			myCommand.Parameters.Add(parameterUserID);

			
			// Open the connection and execute the Command
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myConnection.Close();

			int userId = (int)(parameterUserID.Value);

			if (userId == 0) 
			{
				return null;
			}
			else 
			{
				UserDetails myUserDetails = new UserDetails();
				// Populate Struct using Output Params from SPROC
				myUserDetails.userID = userId;
				myUserDetails.szUserName = szUserName;

				return myUserDetails;
			}
		}
		
		public int ConfirumRegistrationLogin (string szUserName, string gConfirm) 
		{

			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procDoConfirmationLogin", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;

			// Add Parameters to SPROC
			SqlParameter parameterUserName = new SqlParameter("@szUserName", SqlDbType.VarChar, 15);
			parameterUserName.Value = szUserName;
			myCommand.Parameters.Add(parameterUserName);

			SqlParameter parameterGConfirm = new SqlParameter("@gConfirm", SqlDbType.Char, 32);
			parameterGConfirm.Value = gConfirm;
			myCommand.Parameters.Add(parameterGConfirm);

			SqlParameter parameterVerify = new SqlParameter("@iVerify", SqlDbType.Int, 4);
			parameterVerify.Direction = ParameterDirection.Output;
			myCommand.Parameters.Add(parameterVerify);

			
			// Open the connection and execute the Command
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myConnection.Close();

			int iVerify = (int)(parameterVerify.Value);

			return iVerify;


			
		}

		public SqlDataReader GetUserInfo(int userID)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@iUserID" ,SqlDbType.Int, 4, userID)				
			};

			// run the stored procedure
			data.RunProc("procGetUserInfo", prams, out dataReader);

			return dataReader;
		}

		public string GetMemberList()
		{
			// create data object and params
			SqlDataReader reader = null;
			string strList="";
   
			// create params for stored procedure call
			Database data = new Database();			

			// run the stored procedure
			data.RunProc("procGetUserList",out reader);
			
			while(reader.Read())
			{
				strList+= "  " + reader.GetString(1);
				strList+= "  " + reader.GetDateTime(3);
				strList+=  "  " +reader.GetDateTime(4);
				strList+= "  " + reader.GetInt16(5);
				strList+= "  " + reader.GetInt16(6);			
			}

			return strList;
		}

		public static int GetUserPoints(int userID)
		{
			// create data object and params
			SqlDataReader dataReader = null;
			int iPoints = 0;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@iUserID" ,SqlDbType.Int, 4, userID)				
			};

			// run the stored procedure
			data.RunProc("procGetUserPoints", prams, out dataReader);
			while (dataReader.Read())
				iPoints = dataReader.GetInt32(0);
			dataReader.Close();
			
			return iPoints;
		}

		public static int GetNoteStatus(int userID)
		{
			// create data object and params
			SqlDataReader dataReader = null;
			int bNew = 0;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@UserID" ,SqlDbType.Int, 4, userID)				
			};

			// run the stored procedure
			data.RunProc("procGetUserNoteStatus", prams, out dataReader);
			while (dataReader.Read())
			{
				bNew = dataReader.GetInt32(0);
			}
			dataReader.Close();
			if (bNew > 0)
				return 1;
			else
				return 0;			
		}

		public SqlDataReader GetUserArticlePostsByPage(int userID, int currentPage, int pageSize, ref int numSearchResults)
		{
			// create data object and params
			SqlDataReader dataReader = null;

			// create params for stored procedure call
			Database data = new Database();
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@iUserID",          SqlDbType.Int, 4, userID),
				data.MakeInParam("@CurrentPage",		SqlDbType.Int,   4, currentPage),
				data.MakeInParam("@PageSize",			SqlDbType.Int,   4, pageSize),
				data.MakeOutParam("@TotalRecords",	SqlDbType.Int,   4)
			};

			// run the stored procedure
			data.RunProc("procGetUserPostsArticlesByPage", prams, out dataReader);

			// We are getting a value *before* connection is closed (the 
			// docs state that the value is set after the connection is 
			// closed). RecordsAffected returns the the number of rows 
			// changed (0 if no rows were affected or the statement failed 
			// and -1 for SELECT statements).				
			numSearchResults = dataReader.RecordsAffected;
	
				
			return dataReader;
		}
		public SqlDataReader GetUserForumPostsByPage(int userID, int currentPage, int pageSize, ref int numSearchResults)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@iUserID",          SqlDbType.Int, 4, userID),
				data.MakeInParam("@CurrentPage",		SqlDbType.Int,   4, currentPage),
				data.MakeInParam("@PageSize",			SqlDbType.Int,   4, pageSize),
				data.MakeOutParam("@TotalRecords",	SqlDbType.Int,   4)
			};

			// run the stored procedure
			data.RunProc("procGetUserPostsForumsByPage", prams, out dataReader);

			// We are getting a value *before* connection is closed (the 
			// docs state that the value is set after the connection is 
			// closed). RecordsAffected returns the the number of rows 
			// changed (0 if no rows were affected or the statement failed 
			// and -1 for SELECT statements).				
			numSearchResults = dataReader.RecordsAffected;
		
					
			return dataReader;
		}

				
		public SqlDataReader GetLatestLogins() 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procGetLatestLogins", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
			
			// Execute the command
			myConnection.Open();
			SqlDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

			// Return the datareader result
			return result;
			
		}

		public SqlDataReader GetNewestMembers() 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procGetNewestMembers", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
			
			// Execute the command
			myConnection.Open();
			SqlDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

			// Return the datareader result
			return result;
			
		}
	
		public void AddUser (string szUserName, string szFName, string szLName,
			string szEmail, string szPassword,int iAge, string szEducation, 
			string szCountry, string szJob, string szSkills,
			string szFavLang, string szMyComputer, string gConfirm, string szNewMemberNoteBody) 
		{
			
			// create params for stored procedure call
			Database data = new Database();
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@szUserName",		SqlDbType.VarChar, 15, szUserName),
				data.MakeInParam("@szFName",		SqlDbType.VarChar, 50, szFName),
				data.MakeInParam("@szLName",		SqlDbType.VarChar,  50, szLName),
				data.MakeInParam("@szEmail",		SqlDbType.VarChar,  80, szEmail),
				data.MakeInParam("@szPassword",		SqlDbType.VarChar,  15, szPassword),
				data.MakeInParam("@iAge",			SqlDbType.Int,  4, iAge),
				data.MakeInParam("@szEducation",	SqlDbType.VarChar,  50, szEducation),
				data.MakeInParam("@szCountry",		SqlDbType.VarChar,  20, szCountry),
				data.MakeInParam("@szJob",			SqlDbType.VarChar,  50, szJob),
				data.MakeInParam("@szSkills",		SqlDbType.VarChar,  50, szSkills),
				data.MakeInParam("@szFavLang",		SqlDbType.VarChar,  50, szFavLang),
				data.MakeInParam("@szMyComputer",	SqlDbType.VarChar,  100, szMyComputer),
				data.MakeInParam("@gConfirm",		SqlDbType.VarChar,  32, gConfirm),
				data.MakeInParam("@szNewMemberNoteBody",	SqlDbType.VarChar,  250, szNewMemberNoteBody)
				
			};

			// run the stored procedure
			data.RunProc("procAddUserAndInfo", prams);			
			
		}
		
		/// <summary>
		/// Sends the user their password if they forget it via email
		/// </summary>
		/// <param name="strEmail"> The users's email address</param>
		public static int ForgotPassword(string strEmail)
		{
		
			/*
			SmtpMail.Send("DevHood <emitix@mit.edu>", strEmail, "Your Password Request",
				 "Dear " +  myReader.GetString(3) + " " + myReader.GetString(4) + "\n \n This is an aututomatic reply to your password request.  \n \n Your password: " + 
				  myReader.GetString(2) + " \n \n Thank you for using DevHood.  \n \n DevHood");
				  iSuccess = DH_Constants.Success;
			*/ 
			 

			return 1;
		}

		public static string GetUserFromID(int userID)
		{
			SqlDataReader dataReader = null;
			string szUserName = "";
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID)				
			};

			// run the stored procedure
			data.RunProc("procGetUserFromID", prams, out dataReader);
			while (dataReader.Read())
				szUserName = dataReader.GetString(0);
			
			dataReader.Close();
			

			return szUserName;
		}

		/// <summary>
		/// Yesterdays top movers in points
		/// </summary>
		/// <returns></returns>
		public static SqlDataReader GetYesterdaysTopMovers()
		{
			
			Database data = new Database();
			SqlDataReader reader = null;
			
			// run the stored procedure
			data.RunProc("procGetYesterdaysTopMovers", out reader);

								
			return reader;
				
		}

		/// <summary>
		/// Top member in points
		/// </summary>
		/// <returns></returns>
		public static SqlDataReader GetPointLeaders()
		{
			
			Database data = new Database();
			SqlDataReader reader = null;
			
			// run the stored procedure
			data.RunProc("procGetTopUsers", out reader);
								
			return reader;				
		}

		/// <summary>
		/// Top member point leaders for this month
		/// </summary>
		/// <returns></returns>
		public static SqlDataReader GetMonthlyLeaders()
		{
			
			Database data = new Database();
			SqlDataReader reader = null;
			
			// run the stored procedure
			data.RunProc("procGetTopUsersForTheMonth", out reader);
								
			return reader;				
		}

		public static void ConfirmAccount(string szUserName, string szEmail, string gConfirm)
		{
			string strBody = "Welcome to CSharpFriends.com " + szUserName + "! " + CSF.Constants.NLL + CSF.Constants.REGISTRATION_CONFIRMATION_BODY +  CSF.Constants.NLL + "Your confirmation key is " + gConfirm + CSF.Constants.NLL + CSF.Constants.NLL + @"Click here to activate with your key: " + CSF.Constants.ROOT_URL + "/Members/Registered.aspx?un=" + szUserName + "&key=" + gConfirm;
			
			
			System.Web.Mail.MailMessage mm = new System.Web.Mail.MailMessage();
			mm.From = System.Configuration.ConfigurationSettings.AppSettings["AdminEmail"];
			mm.To = szEmail;
			mm.Subject = "[csharpfriends.com] Registration Confirmation";
			mm.Body = strBody;
			mm.BodyFormat = System.Web.Mail.MailFormat.Text;

			System.Web.Mail.SmtpMail.Send(mm);
		
		}

		public void UpdateUserInfo(int userID, string szFName, string szLName, int iAge,
			string szEducation, string szCountry, string szJob, string szSkills, string szFavLang,
			string szMyComputer)
		{
			
			// create params for stored procedure call
			Database data = new Database();
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@UserID",			SqlDbType.Int, 4, userID),
				data.MakeInParam("@szFName",		SqlDbType.VarChar, 50, szFName),
				data.MakeInParam("@szLName",		SqlDbType.VarChar,  50, szLName),
				data.MakeInParam("@iAge",			SqlDbType.Int,  4,iAge),
				data.MakeInParam("@szEducation",	SqlDbType.VarChar,  50, szEducation),
				data.MakeInParam("@szCountry",		SqlDbType.VarChar,  20, szCountry),
				data.MakeInParam("@szJob",			SqlDbType.VarChar,  50, szJob),
				data.MakeInParam("@szSkills",		SqlDbType.VarChar,  50, szSkills),
				data.MakeInParam("@szFavLang",		SqlDbType.VarChar,  50, szFavLang),
				data.MakeInParam("@szMyComputer",	SqlDbType.VarChar,  100, szMyComputer)
		
			};

			// run the stored procedure
			data.RunProc("procUserUpdateInfo", prams);			
		}

		/// <summary>
		/// list of users submissions (tutorials)
		/// </summary>
		/// <param name="userID">userID</param>
		/// <returns>data reader</returns>
		public SqlDataReader GetSubmittedTutorials(int userID)
		{
			// create data object and params
			SqlDataReader reader = null;
			   
			// create params for stored procedure call
			Database data = new Database();			
			
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@UserID",			SqlDbType.Int, 4, userID)		
			};

			// run the stored procedure
			data.RunProc("procGetUserSubmittedTutorials", prams ,out reader);						

			return reader;
		}
		/// <summary>
		/// list of users forum subscriptions
		/// </summary>
		/// <param name="userID">userID</param>
		/// <returns>data reader</returns>
		public SqlDataReader GetSubscriptions(int userID)
		{
			// create data object and params
			SqlDataReader reader = null;
			   
			// create params for stored procedure call
			Database data = new Database();			
			
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@UserID",			SqlDbType.Int, 4, userID)		
			};

			// run the stored procedure
			data.RunProc("procGetUserSubscriptions", prams ,out reader);						

			return reader;
		}






	} // end 
} // namespace
