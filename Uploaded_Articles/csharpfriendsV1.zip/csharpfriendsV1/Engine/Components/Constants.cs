using System;
using System.Configuration;

namespace CSF
{
	/// <summary>
	/// Constants used throughout the site
	/// </summary>
	public class Constants
	{
		// New Line
		public static readonly string NL = System.Environment.NewLine;
		// New Line x 2
		public static readonly string NLL = System.Environment.NewLine + System.Environment.NewLine;

		// Web Site Url
		public static readonly string SUBSCRIPTION_EMAIL = System.Configuration.ConfigurationSettings.AppSettings["AdminEmail"];
		public static readonly string JOIN_EMAIL = System.Configuration.ConfigurationSettings.AppSettings["AdminEmail"];
		
		public static readonly string ROOT_URL = ConfigurationSettings.AppSettings["RootURL"];
				
		// Articles location 
		public static readonly string ARTICLE_ROOT = ConfigurationSettings.AppSettings["RootPath"] + "/Members/Main/Channels/Articles";
		public static readonly string TUTORIAL_ROOT = ConfigurationSettings.AppSettings["RootPath"] + "/Members/Tutorials";

		//specifications files location
		public static readonly string SPECIFICATION_ROOT = ConfigurationSettings.AppSettings["RootPath"] + "/Members/Main/Spec/files";
		public static readonly string SOUCE_FORUMS_ROOT = ConfigurationSettings.AppSettings["RootPath"] + "/Members/Main/Source/files";
		
		// Page Sizes for paging throughout the site
		public static readonly int ARTICLE_REPLIES_PAGESIZE = 5;
		public static readonly int FORUM_MESSAGES_PAGESIZE = 10;
		public static readonly int FORUM_THREAD_PAGESIZE = 10;
		public static readonly int NOTES_PAGESIZE = 15; 
		public static readonly int QUESTIONS_PAGESIZE = 5; 

		// Member Points
		public static readonly int PTS_LOGIN = 10;	//daily login bonus
		public static readonly int PTS_FORUM_POST = 1;
		public static readonly int PTS_FORUM_REPLY = 2;
		public static readonly int PTS_ARTICE_POST = 1;
		//public static readonly int PTS_ARTICLE_EMAIL = 1;  //email to friend
		public static readonly int PTS_POLL_VOTE = 1;
		public static readonly int PTS_QOD_Reply = 1;

		public static readonly int PTS_WRITE_ARTICLE = 50;
		public static readonly int PTS_WRITE_TUTORIAL = 25;
		

		// Registration Confirmation
		public static readonly string REGISTRATION_CONFIRMATION_BODY =  "At CSharpfriends we encourage you to get involved.  Ask questions, help others out and earn member points.  Members with the most points earned in a month win FREE prizes!";
		public static readonly string SLOGAN = CSF.Constants.ROOT_URL + NLL + " World's Greatest C# Communit Site!";

		// Invite a friend
		public static readonly string InviteEmailBody = @" has graciously invited you to join CSharpfriends.com, the worlds greatest C# community site.  Registration is FREE and easy.  Being a member of CSharpFriends.com will make you part of a community that thrives on helping each other.  This is your chance to get in touch with others who share your desire to become experts in ASP.Net and more specifically C#!  Express your I.T related opinions in polls, forums and comment on article posts and much much more.  So what are you waiting for? Your only one click away!  CSharpFriends Admin.  http://" + CSF.Constants.ROOT_URL ;
		
		// New User Note Message
		public static readonly string NEW_USER_NOTE_BODY = @"Hi!<br><br>The notes section allows you to send private messages to other users.<br><br>Enjoy!";
		
		public static string getQuote(int index, string user)
		{
			
			user = "<SPAN CLASS=red>" + user + "</SPAN>";
			
			string[] msg = new string[] {
											"I'd like to thank my parents, my producer, " + user + ", my fans�",
											"I don't think we're in Kansas anymore, " + user,
											"Its a bird, its a plane, its " + user,
											user + " likes to code till dawn",
											"Whatchu talkin' 'bout, " + user + "?",
											"Do you understand the words that are coming out of my mouth " + user +"?",
											user + "-alicious!",
											"So, " + user + ", how YOU doin'?",
											user + " codes in his free time",
											"using System." + user + ";",
											user + ".ToString();",
											user + "! Did you defrag you drive today?",
											user + " loves C# and doesn't care who knows it!",
											user + ", MCSE, MSCD, A+, CCNA, CCIE, PHD.",
											user + " 1GHZ, 512 MB",
											"E=MC<sup>" + user + "</sup>",
											user + ", this is your brain on CSharpFriends.",
											"Response.Write(" + user + ");",
											"Go ahead...make my day," + user + "."
										};
			return msg[index];
		}
	
		
		
	}
}
