using System;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

namespace CSF
{
	/// <summary>
	/// Site Polls, voting, results etc
	/// </summary>
	public class PollDB
	{
	
		public SqlDataReader getPollQuestion(int pollID)
		{
			// create data object and params
			SqlDataReader reader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@pollID" ,SqlDbType.Int, 4, pollID)
			};

			// run the stored procedure
			data.RunProc("procGetPollQuestion", prams, out reader);
									
			return reader;
	    }

		public SqlDataReader getPollChoices(int pollID)
		{
			// create data object and params
			SqlDataReader reader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@pollID" ,SqlDbType.Int, 4, pollID)
			};

			// run the stored procedure
			data.RunProc("procGetPollChoices", prams, out reader);
									
			return reader;
		}

		public void putPollVote(int pollID, int choiceID, int userID)
		{
			// create data object and params
			//SqlDataReader reader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@pollID" ,SqlDbType.Int, 4, pollID),
				data.MakeInParam("@choiceID" ,SqlDbType.Int, 4, choiceID),
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID)
			};

			// run the stored procedure
			data.RunProc("procPutPollVote", prams);
				
			
		}


	}  //pollDB
} //nameSpace
