using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CSF
{
	//*******************************************************
	//
	// ForumsDB Class
	//
	// Business Data Logic Class that encapsulates all data
	// logic necessary to view and post questions to the
	// forums database.
	//
	//*******************************************************

	public class ForumsDB 
	{
		/// <summary>
		/// Retrieve all the main forum topics
		/// </summary>
		/// <returns></returns>
		public SqlDataReader GetForums() 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procGetForums", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
			
			// Execute the command
			myConnection.Open();
			SqlDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
			
			// Return the datareader result
			return result;
			
		}

		/// <summary>
		/// Retrieve paged messages for a specified forum topic
		/// </summary>
		/// <param name="forumID">int forumID</param>
		/// <param name="currentPage">int</param>
		/// <param name="pageSize">int pageSize</param>
		/// <param name="numSearchResults">int numSearchResults</param>
		/// <returns>SqlDataReader</returns>
		public SqlDataReader GetForumMessagesByPage(int forumID, int currentPage, int pageSize, ref int numSearchResults)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@forumID",          SqlDbType.Int, 4, forumID),
				data.MakeInParam("@CurrentPage",		SqlDbType.Int,   4, currentPage),
				data.MakeInParam("@PageSize",			SqlDbType.Int,   4, pageSize),
				data.MakeOutParam("@TotalRecords",	SqlDbType.Int,   4)
			};

			// run the stored procedure
			data.RunProc("procGetForumMessagesByPage", prams, out dataReader);

			// We are getting a value *before* connection is closed (the 
			// docs state that the value is set after the connection is 
			// closed). RecordsAffected returns the the number of rows 
			// changed (0 if no rows were affected or the statement failed 
			// and -1 for SELECT statements).				
			numSearchResults = dataReader.RecordsAffected;
								
			return dataReader;
		}

		
		public SqlDataReader GetForumMessage(int forumID, int messageID)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@forumID",          SqlDbType.Int, 4, forumID),
				data.MakeInParam("@messageID",		SqlDbType.Int,   4, messageID)
			};

			// run the stored procedure
			data.RunProc("procGetForumMessage", prams, out dataReader);
							
			return dataReader;
		}


		/// <summary>
		/// Retrieve paged posts to a specified message
		/// </summary>
		/// <param name="forumID">int forumID</param>
		/// <param name="messageID">int messageID</param>
		/// <param name="currentPage">int currentPage</param>
		/// <param name="pageSize">int pageSize</param>
		/// <param name="numSearchResults">int numSearchResults</param>
		/// <returns>SqlDataReader</returns>
		public SqlDataReader GetForumThreadsByPage(int forumID, int messageID, int currentPage, int pageSize, ref int numSearchResults)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();
			SqlParameter[] prams =
				{                     
					data.MakeInParam("@forumID",          SqlDbType.Int, 4, forumID),
					data.MakeInParam("@messageID",          SqlDbType.Int, 4, messageID),
					data.MakeInParam("@CurrentPage",		SqlDbType.Int,   4, currentPage),
					data.MakeInParam("@PageSize",			SqlDbType.Int,   4, pageSize),
					data.MakeOutParam("@TotalRecords",	SqlDbType.Int,   4)
				};
	
			// run the stored procedure
			data.RunProc("procGetForumThreadsByPage", prams, out dataReader);
	
			// We are getting a value *before* connection is closed (the 
			// docs state that the value is set after the connection is 
			// closed). RecordsAffected returns the the number of rows 
			// changed (0 if no rows were affected or the statement failed 
			// and -1 for SELECT statements).				
			numSearchResults = dataReader.RecordsAffected;

			return dataReader;
		}

		/// <summary>
		/// Puts a forum thread by a user for a forum message 
		/// </summary>
		/// <param name="userID">int userID</param>
		/// <param name="forumID">int forumID</param>
		/// <param name="messageID">int messageID</param>
		/// <param name="commentThread">string commentThread</param>
		/// <param name="PTS_FORUM_REPLY">int PTS_FORUM_REPLY</param>
		public void PutForumThreads(int userID, int forumID, int messageID, string commentThread, int PTS_FORUM_REPLY) 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procPutForumThread", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
			
			// Add Parameters to SPROC
			SqlParameter parameterUserID = new SqlParameter("@userID", SqlDbType.Int, 4);
			parameterUserID.Value = userID;
			myCommand.Parameters.Add(parameterUserID);

			// Add Parameters to SPROC
			SqlParameter parameterForumID = new SqlParameter("@forumID", SqlDbType.Int, 4);
			parameterForumID.Value = forumID;
			myCommand.Parameters.Add(parameterForumID);

			// Add Parameters to SPROC
			SqlParameter parameterMessageID = new SqlParameter("@messageID", SqlDbType.Int, 4);
			parameterMessageID.Value = messageID;
			myCommand.Parameters.Add(parameterMessageID);

			
			SqlParameter parameterCommentThread = new SqlParameter("@commentThread", SqlDbType.NVarChar,3000);
			parameterCommentThread.Value = Posting.parsetext(commentThread,false);
			myCommand.Parameters.Add(parameterCommentThread);

			SqlParameter parameterReplyPoints = new SqlParameter("@PTS_FORUM_REPLY", SqlDbType.Int,4);
			parameterReplyPoints.Value = PTS_FORUM_REPLY;
			myCommand.Parameters.Add(parameterReplyPoints);
			
			// Execute the command
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myConnection.Close();
			
			//Send Out Subscription emails
			EmailSubscriptions(userID, messageID, "[csharpfriends.com]", commentThread);
			
		}	

		/// <summary>
		/// Puts a forum message for a specified forum category
		/// </summary>
		/// <param name="userID">int userID</param>
		/// <param name="forumID">int forumID</param>
		/// <param name="Topic">string Topic</param>
		/// <param name="Message">string message</param>
		/// <param name="PTS_FORUM_POST">int PTS_FORUM_POST</param>
		public void PutForumMessage(int userID, int forumID,string Topic, string Message, int PTS_FORUM_POST) 
		{
									
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procPutForumMessage", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
			
			// Add Parameters to SPROC
			SqlParameter parameterUserID = new SqlParameter("@userID", SqlDbType.Int, 4);
			parameterUserID.Value = userID;
			myCommand.Parameters.Add(parameterUserID);

			// Add Parameters to SPROC
			SqlParameter parameterForumID = new SqlParameter("@forumID", SqlDbType.Int, 4);
			parameterForumID.Value = forumID;
			myCommand.Parameters.Add(parameterForumID);

			SqlParameter parameterTopic = new SqlParameter("@szTopic", SqlDbType.VarChar,250);
			parameterTopic.Value = Topic;
			myCommand.Parameters.Add(parameterTopic);

			SqlParameter parameterMessage = new SqlParameter("@szMessage", SqlDbType.NVarChar,3000);
			parameterMessage.Value = Posting.parsetext(Message,false);
			myCommand.Parameters.Add(parameterMessage);
			
			SqlParameter parameterPTS_FORUM_POST = new SqlParameter("@PTS_FORUM_POST", SqlDbType.Int,4);
			parameterPTS_FORUM_POST.Value = PTS_FORUM_POST;
			myCommand.Parameters.Add(parameterPTS_FORUM_POST);

			// Execute the command
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myConnection.Close();
			
		}	
		
		
		/// <summary>
		/// Retrieves members latest posts/messages
		/// </summary>
		/// <returns>SqlDataReader</returns> 
		public SqlDataReader GetNewMessages() 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procGetNewMessages", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
			
			// Execute the command
			myConnection.Open();
			SqlDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
			
			// Return the datareader result
			return result;
			
		}
		
		/// <summary>
		/// Gets the bread crumbs that trail above the forums for simple navigation
		/// </summary>
		/// <param name="forumID">int forumID</param>
		/// <param name="messageID">int messageID</param>
		/// <returns>DataTable</returns>
		public DataTable GetBreadCrumbs(int forumID, int messageID) 
		{
			string strSQL = "procGetForumBreadCrumbs " + forumID + "," + messageID;
			
			Database db = new Database();
			DataTable dt = db.GetDataTable(strSQL,ConfigurationSettings.AppSettings["ConnectionString"]);
			
			return dt;
			
		}

		/// <summary>
		/// Adds a user to a forum message subscription
		/// </summary>
		/// <param name="userID">userID</param>
		/// <param name="messageID">messageID</param>
		public void PutMessageSubscription (int userID, int messageID)
		{
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID),
				data.MakeInParam("@messageID" ,SqlDbType.Int, 4, messageID)
			};

			// run the stored procedure
			data.RunProc("procPutForumSubscription", prams);						
		}

		/// <summary>
		/// Deletes a users forum subscription
		/// </summary>
		/// <param name="userID">int userID</param>
		/// <param name="messageID">int messageID</param>
		public void DeleteMessageSubscription (int userID, int messageID)
		{
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID),
				data.MakeInParam("@messageID" ,SqlDbType.Int, 4, messageID)
			};

			// run the stored procedure
			data.RunProc("procDeleteForumSubscription", prams);								
		}

		/// <summary>
		/// Emails out updates to a forum message to subscribed users
		/// </summary>
		/// <param name="userID">int userID</param>
		/// <param name="messageID">int messageID</param>
		/// <param name="strSubject">string subject</param>
		/// <param name="strBody">string body</param>
		public void EmailSubscriptions(int userID, int messageID, string strSubject, string strBody)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();
			
			SqlParameter[] prams =
				{                     
					data.MakeInParam("@messageID",          SqlDbType.Int, 4, messageID)
				};
	
			// run the stored procedure
			data.RunProc("procGetForumSubscriptions", prams, out dataReader);

			string szUserName = CSF.UsersDB.GetUserFromID(userID);
			string strTo = "";
			
			//Append user name of poster to body of message
			strBody = string.Concat("CSharpFriends.com, Worlds Greatest Interactive .Net Community Site!\n","Message by: ", szUserName,"\n\n",strBody);

			while (dataReader.Read())
			{
				strTo =	dataReader.GetString(0);

				System.Web.Mail.MailMessage mm = new System.Web.Mail.MailMessage();
				mm.From = CSF.Constants.SUBSCRIPTION_EMAIL;
				mm.To = strTo;
				mm.Subject = strSubject;
				mm.Body = strBody;
				
				mm.BodyFormat = System.Web.Mail.MailFormat.Text;
				System.Web.Mail.SmtpMail.Send(mm);
			}
		
		}


	} // ForumsDB

} // namespace