using System;
using System.Data;
using System.Data.SqlClient;

namespace CSF
{
	/// <summary>
	/// Summary description for Books.
	/// </summary>
	public class Books
	{
		public Books()
		{			
		}
		
		public static SqlDataReader GetSampleList()
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();
			
			// run the stored procedure
			data.RunProc("procGetBookSampleList",out dataReader);

			return dataReader;
		}
	}
}
