using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CSF
{
	/// <summary>
	/// Summary description for ChannelsDB.
	/// </summary>
	public class ChannelsDB
	{
		//*******************************************************
		//    grabs all the Channels
		//
		//*******************************************************

		public SqlDataReader GetChannels() 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procGetChannels", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
							
			// Execute the command
			myConnection.Open();
			SqlDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

			// Return the datareader result
			return result;
			
		}
		
		/***************************************
		 *  grabs feature articles
		 *
		 ****************************************/
		public SqlDataReader GetFeatures() 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procGetFeatureArticles", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
							
			// Execute the command
			myConnection.Open();
			SqlDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

			// Return the datareader result
			return result;
			
		}

		public SqlDataReader GetChannelArticles (int channelID) 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procGetChannelIndex", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
						
			// Add Parameters to SPROC
			SqlParameter parameterChannelID = new SqlParameter("@channelID", SqlDbType.Int, 4);
			parameterChannelID.Value = channelID;
			myCommand.Parameters.Add(parameterChannelID);
			

			// Execute the command
			myConnection.Open();
			SqlDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

			// Return the datareader result
			return result;
		}


	}
}
