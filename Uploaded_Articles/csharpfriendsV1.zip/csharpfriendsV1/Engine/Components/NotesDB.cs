using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CSF
{
	/// <summary>
	/// Summary description for NotesDB.
	/// </summary>
	public class NotesDB
	{
			
		
		public SqlDataReader GetNotesByPage(int userID, int currentPage, int pageSize, ref int numSearchResults)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID),
				data.MakeInParam("@CurrentPage" ,SqlDbType.Int,   4, currentPage),
				data.MakeInParam("@PageSize" ,SqlDbType.Int,   4, pageSize),
				data.MakeOutParam("@TotalRecords" ,SqlDbType.Int,   4)
			};

			// run the stored procedure
			data.RunProc("procGetNotesByPage", prams, out dataReader);

			// We are getting a value *before* connection is closed (the 
			// docs state that the value is set after the connection is 
			// closed). RecordsAffected returns the the number of rows 
			// changed (0 if no rows were affected or the statement failed 
			// and -1 for SELECT statements).				
			numSearchResults = dataReader.RecordsAffected;
		
					
			return dataReader;
		}

		public SqlDataReader GetNote(int userID, int noteID)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID),
				data.MakeInParam("@noteID" ,SqlDbType.Int,   4, noteID)
			};

			// run the stored procedure
			data.RunProc("procGetNote", prams, out dataReader);

			return dataReader;
		}
		
		public int PutNote(int userID, string szTo, string szCC, string szBCC, string szSubject, string szMessage)
		{
			   
			int bPass;	//pass/fail boolean
            Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID),
				data.MakeInParam("@szTo" ,SqlDbType.VarChar, 15, szTo),
				data.MakeInParam("@szCC" ,SqlDbType.VarChar, 30, szCC),
				data.MakeInParam("@szBCC" ,SqlDbType.VarChar, 30, szBCC),
				data.MakeInParam("@szSubject" ,SqlDbType.VarChar, 100, szSubject),
				data.MakeInParam("@szMessage" ,SqlDbType.VarChar, 3000, Posting.parsetext(szMessage,false)),
				data.MakeOutParam("@bPass", SqlDbType.Int, 4)
			};

			// run the stored procedure
			data.RunProc("procPutNote", prams);
			bPass = (int)prams[6].Value;     // get the output param value

			// if the customer id is an empty string, then the login failed
			if (bPass > 0)
				return 1;
			else
				return 0;
		}

		//delete single note while viewing a note
		public void DeleteNote(int userID, int noteID)
		{
						   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID),
				data.MakeInParam("@noteID" ,SqlDbType.Int,   4, noteID)
			};

			// run the stored procedure
			data.RunProc("procDeleteNote", prams);
						
		}

		//used to delete mulitple notes
		public void DeleteNotes(int userID, string szWhereClause)
		{
						   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID),
				data.MakeInParam("@szWhereClause" ,SqlDbType.VarChar,255, szWhereClause)
			};

			// run the stored procedure
			data.RunProc("procDeleteNotes", prams);
						
		}
	
		public int checkForNewNotes(int userID)
		{
			
			int bNew = 0;  // status for new notes 1 = new

			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@userID" ,SqlDbType.Int, 4, userID),
				data.MakeOutParam("@bNew", SqlDbType.Int, 4)
			};

			// run the stored procedure
			data.RunProc("procNewNotes", prams);

			return bNew = (int)prams[1].Value; 
		}


	} // class NotesDB

} // namespace
