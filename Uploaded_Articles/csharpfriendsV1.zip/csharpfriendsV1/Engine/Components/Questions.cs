using System;
using System.Data;
using System.Data.SqlClient;

namespace CSF
{
	/// <summary>
	/// Questions class
	/// </summary>
	public class Questions
	{
		/// <summary>
		/// Empty Constructor
		/// </summary>
		public Questions()
		{			
		}

		/// <summary>
		/// Retrieve Question text by ID
		/// </summary>
		/// <param name="tutorialID"></param>
		/// <returns></returns>
		public static SqlDataReader GetByID(int questionID) 
		{
						
			SqlDataReader dataReader = null;
			
			Database data = new Database();

			SqlParameter[] prams =
			{
				//data.MakeInParam("@SiteID", SqlDbType.Int, 4, TWG.Constants.SiteID),
				data.MakeInParam("@QuestionID", SqlDbType.Int, 4, questionID)
				
			};
						  
			data.RunProc("procQuestionGetByID", prams, out dataReader); 


			return dataReader;	
		}

		/// <summary>
		/// Retrieve Question replies by ID
		/// </summary>
		/// <param name="tutorialID"></param>
		/// <returns></returns>
		public static SqlDataReader GetRepliesByID(int questionID, int currentPage, int pageSize, ref int numSearchResults) 
		{
						
			SqlDataReader dataReader = null;
			
			Database data = new Database();

			SqlParameter[] prams =
			{
				//data.MakeInParam("@SiteID",			SqlDbType.Int, 4, TWG.Constants.SiteID),
				data.MakeInParam("@QuestionID",		SqlDbType.Int, 4, questionID),
				data.MakeInParam("@CurrentPage",	SqlDbType.Int, 4, currentPage),
				data.MakeInParam("@PageSize",		SqlDbType.Int, 4, pageSize),
				data.MakeOutParam("@TotalRecords",	SqlDbType.Int, 4)
				
			};
						  
			data.RunProc("procQuestionGetRepliesByID", prams, out dataReader); 

			// We are getting a value *before* connection is closed (the 
			// docs state that the value is set after the connection is 
			// closed). RecordsAffected returns the the number of rows 
			// changed (0 if no rows were affected or the statement failed 
			// and -1 for SELECT statements).				
			numSearchResults = dataReader.RecordsAffected;


			return dataReader;
		}

		/// <summary>
		/// TODO: add ponts to this
		/// Insert a reply to a question
		/// </summary>
		/// <param name="tutorialID"></param>
		/// <returns></returns>
		public static void InsertReply(int questionID, int userID, string replyText) 
		{
			Database data = new Database();

			SqlParameter[] prams =
			{
				data.MakeInParam("@ReplyPoints",SqlDbType.Int, 4, CSF.Constants.PTS_QOD_Reply),
				data.MakeInParam("@QuestionID", SqlDbType.Int, 4, questionID),
				data.MakeInParam("@UserID",		SqlDbType.Int, 4, userID),
				data.MakeInParam("@Message",	SqlDbType.VarChar, 1975, Posting.parsetext(replyText,false))
				
			};
						  
			// insert to db, award points
			data.RunProc("procQuestionInsertReply", prams); 
		}
	}
}
