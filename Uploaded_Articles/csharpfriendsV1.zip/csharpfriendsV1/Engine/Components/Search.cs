using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace CSF
{
	/// <summary>
	/// Search Tutorials, Forums for keywords
	/// </summary>
	public class Search
	{
		public Search()
		{			
		}		
		
		public static string FormatQeuryString(string strQuery)
		{
			string strNewQuery = null;
            
			if (strQuery[0] != '\"') 
			{
				// This is adding the '' when ado does this automagically!
				//StringBuilder sb = new StringBuilder("\'\"");
				StringBuilder sb = new StringBuilder("\"");
				
				sb.Append("*");
				sb.Append(strQuery);
				sb.Append("*");
				sb.Append("\"");
				sb.Replace(" ", "*\" or \"*");
				//sb.Append("'");
				strNewQuery = sb.ToString();
			} 
			else 
			{
				strNewQuery = strQuery;
			}

			return strNewQuery;
		}

		public static SqlDataReader Tutorials (string strQuery)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@strQuery",  SqlDbType.VarChar, 200, strQuery)				
			};

			// run the stored procedure
			data.RunProc("procSearchTutorials", prams, out dataReader);

			//System.Web.HttpContext.Current.Response.Write("class=" + strQuery);

								
			return dataReader;
		}


	}
}