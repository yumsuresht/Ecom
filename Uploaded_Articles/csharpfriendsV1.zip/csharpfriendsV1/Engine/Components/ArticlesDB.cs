using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CSF  
{
	//*******************************************************
	//
	// QuestionsDB Class
	//
	// Business/Data Logic Class that encapsulates all data
	// logic necessary to list/access/add questions from
	// the database.
	//
	//*******************************************************

	public class ArticlesDB 
	{
		//*******************************************************
		//    grabs all the user replies to a Article
		//
		//*******************************************************
		
		public string GetArticleFileName(int ArticleID) 
		{
			string szFileName;

			// create data object and params
			Database data = new Database();

			SqlParameter[] prams =
			{
				data.MakeInParam("@ArticleID", SqlDbType.Int, 4, ArticleID),
				data.MakeOutParam("@szFileName", SqlDbType.VarChar, 20)
			};
						  
			data.RunProc("procGetArticleFileName", prams);    // run the stored procedure
			szFileName = (string) prams[1].Value;      // get the output param value
			return szFileName + ".htm";
		}
				
		
		//*******************************************************
		//    grabs all the user replies to a Article
		//
		//*******************************************************

		public SqlDataReader GetReplies(int ArticleID) 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procGetArticleReplies", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;

			// Add Parameters to SPROC
			SqlParameter parameterArticleID = new SqlParameter("@ArticleID", SqlDbType.Int, 4);
			parameterArticleID.Value = ArticleID;
			myCommand.Parameters.Add(parameterArticleID);

			// Execute the command
			myConnection.Open();
			SqlDataReader result = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

			// Return the datareader result
			return result;
		}

		public SqlDataReader GetArticleRepliesByPage(int articleID, int currentPage, int pageSize, ref int numSearchResults)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();
			SqlParameter[] prams =
			{                     
				data.MakeInParam("@articleID",          SqlDbType.Int, 4, articleID),
				data.MakeInParam("@CurrentPage",		SqlDbType.Int,   4, currentPage),
				data.MakeInParam("@PageSize",			SqlDbType.Int,   4, pageSize),
				data.MakeOutParam("@TotalRecords",	SqlDbType.Int,   4)
			};

			// run the stored procedure
			data.RunProc("procGetArticleRepliesByPage", prams, out dataReader);

			// We are getting a value *before* connection is closed (the 
			// docs state that the value is set after the connection is 
			// closed). RecordsAffected returns the the number of rows 
			// changed (0 if no rows were affected or the statement failed 
			// and -1 for SELECT statements).				
			numSearchResults = dataReader.RecordsAffected;
		
					
			return dataReader;
		}



		public void PutArticleReply(int userID, int ArticleID, string Reply, int PTS_ARTICE_POST) 
		{
			// Create Instance of Connection and Command Object
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConnectionString"]);
			SqlCommand myCommand = new SqlCommand("procPutArticleReply", myConnection);

			// Mark the Command as a SPROC
			myCommand.CommandType = CommandType.StoredProcedure;
			
			// Add Parameters to SPROC
			SqlParameter parameterUserID = new SqlParameter("@userID", SqlDbType.Int, 4);
			parameterUserID.Value = userID;
			myCommand.Parameters.Add(parameterUserID);

			// Add Parameters to SPROC
			SqlParameter parameterArticleID = new SqlParameter("@ArticleID", SqlDbType.Int, 4);
			parameterArticleID.Value = ArticleID;
			myCommand.Parameters.Add(parameterArticleID);

			SqlParameter parameterReply = new SqlParameter("@szReply", SqlDbType.VarChar,3000);
			parameterReply.Value =  Posting.parsetext(Reply,false);
			myCommand.Parameters.Add(parameterReply);

			SqlParameter parameterReplyPts = new SqlParameter("@ReplyPts", SqlDbType.Int, 4);
			parameterReplyPts.Value =  PTS_ARTICE_POST;
			myCommand.Parameters.Add(parameterReplyPts);
			
			// Execute the command
			myConnection.Open();
			myCommand.ExecuteNonQuery();
			myConnection.Close();
			
		}	
		
		public String getArticleText(int articleID)
		{
			string fileName = GetArticleFileName(articleID);
									
			System.IO.StreamReader sr = System.IO.File.OpenText( Constants.ARTICLE_ROOT + "\\" + 	fileName );
			String text = sr.ReadToEnd();
			sr.Close();
			return text;
		}

	} // ArticlesDB

} // namespace