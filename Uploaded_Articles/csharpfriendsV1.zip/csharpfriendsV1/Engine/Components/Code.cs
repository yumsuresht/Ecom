using System;
using System.Web;
using System.IO;
using System.Text.RegularExpressions;

namespace CSF
{
	/// <summary>
	/// Summary description for Code.
	/// </summary>
	public class Code 
	{

		private const string STR_FIELDNAME  = "<span class=fieldname>";
		private const string STR_COMMENT    = "<span class=comment>";
		private const string STR_TAGNAME    = "<span class=tagname>";
		private const string STR_FIELDVALUE = "<span class=fieldvalue>";
		private const string STR_BRACKET    = "<span class=bracket>";
		private const string STR_CS            = "<span class=cs>";
		private const string STR_ENDTAG     = "</span>";

		/// <summary>
		/// Returns a string of HTML after formatting input with colors used in Visual.NET for ASPX code.
		/// </summary>
		/// <param name="strCode"> ASPX code in string format </param>
		public static string ColorASPXCode(string strCode) 
		{

			StringReader srPlainCode = new StringReader(strCode);
			StringWriter swColoredCode = new StringWriter();
            
			string strLine;
			string strSearch;
			string strReplace;

			while (-1 != srPlainCode.Peek()) 
			{

				strLine = srPlainCode.ReadLine();

				if ((null != strLine) && (0 != strLine.Length)) 
				{

					// Search for \t and replace it with 4 spaces. 
					strSearch = @"(?i)(\t)";
					strReplace = "    " ;
					if (Regex.IsMatch(strLine, strSearch)) 
					{
						strLine = Regex.Replace(strLine, strSearch, strReplace);
					}

					// Search and replace "<" char.
					strSearch = "(?i)(<)";
					strReplace = "<";
					if (Regex.IsMatch(strLine, strSearch)) 
					{
						strLine = Regex.Replace(strLine, strSearch, strReplace);
					}

					// Search and replace ">" char.        
					strSearch = "(?i)(>)";
					strReplace = ">";
					if (Regex.IsMatch(strLine, strSearch)) 
					{
						strLine = Regex.Replace(strLine, strSearch, strReplace);
					}

					// Single line comment
					strSearch = "(?i)(?<a>(^.*))(?<b>(<!--))(?<c>(.*))(?<d>(-->))(?<e>(.*))";
					strReplace = String.Concat("${a}", STR_COMMENT,"<!--", "${c}", "-->", STR_ENDTAG, "${e}");
					if (Regex.IsMatch(strLine, strSearch)) 
					{
						strLine = Regex.Replace(strLine, strSearch, strReplace);
					}
					else 
					{

						// Multi-line comment
						strSearch = "(?<a>(^.*))(?<b>(<!--))(?<c>(.*))";
						strReplace = String.Concat("${a}", STR_COMMENT, "<!--", "${c}", STR_ENDTAG);
						if (Regex.IsMatch(strLine, strSearch)) 
						{
							strLine = Regex.Replace(strLine, strSearch, strReplace);
							swColoredCode.Write(strLine + "<br>");

							strSearch = @"(?<a>(^\s*))(?<b>(.*))(?<c>(-->))";
							do 
							{
								strLine = srPlainCode.ReadLine();
								strLine = Regex.Replace(strLine, "\t", "    ");
								strLine = Regex.Replace(strLine, "<", "<");
								strLine = Regex.Replace(strLine, ">", ">");
								if (!Regex.IsMatch(strLine, strSearch)) 
								{
									swColoredCode.Write( String.Concat(STR_COMMENT, strLine, STR_ENDTAG, "\n") );
								}
							} while (!Regex.IsMatch(strLine, strSearch));

							strReplace = String.Concat("${a}", STR_COMMENT, "${b}", "-->", STR_ENDTAG);
							strLine = Regex.Replace(strLine, strSearch, strReplace);
						}
						else 
						{

							// Colorize <%@
							strSearch = @"(?i)(?<a>^\s*)(?<b>((<%(@))(.*)(%>)))";
							if (Regex.IsMatch(strLine, strSearch)) 
							{
								int iSpacing = strLine.IndexOf("<%");
								string strSpacer = "";
								for (int i=0; i<=iSpacing; i++) 
								{
									strSpacer = strSpacer + " ";
								}
								strReplace = String.Concat("<table border=0 cellpadding=0 cellspacing=0><tr><td>", strSpacer, "</td><td class=reference>", "${b}", "</td></tr></table>");
								strLine = Regex.Replace(strLine, strSearch, strReplace);
							}

							// Colorize tag <type>    
							strSearch = @"(?i)(?<a>(<)(?!%)(?!/?asp:)(?!/?template\s)(?!/?property\s)(?!/?script\s)(?!/?meta\s)(?!/?a\s)(?!/?form\s)(?!/?table\s)(?!/?tr\s)(?!/?td\s)(/|!)?)(?<b>[^\s&]+)(?<c>(\s|>|\Z))";
							strReplace = String.Concat("${a}", STR_TAGNAME, "${b}", STR_ENDTAG, "${c}");
							if (Regex.IsMatch(strLine, strSearch)) 
							{
								strLine = Regex.Replace(strLine, strSearch, strReplace);
							}

							// Colorize asp:|template|property|script etc. tags, fields, and values
							strSearch = @"(?i)(?<a></?)(?<b>\s?(asp:(\S*?((?=>)|(?=\s)))|template|property|script|meta|a|form|table|tr|td)\s)(?<c>(.*?>))";
							strReplace = String.Concat("${a}", STR_TAGNAME, "${b}", STR_ENDTAG, "${c}");
							if (Regex.IsMatch(strLine,strSearch)) 
							{

								// Coloring fields and values
								//string strNestedSearch = @"(?i)(?<a>[^ \f\n\r\t\v=]+\s*)=(?<b>\s*\S+)";
								string strNestedSearch = @"(?i)(?<a>[^ \f\n\r\t\v=]+\s*)=(?<b>\s*[^\s&]+)";
								string strNestedReplace = String.Concat(STR_FIELDNAME, "${a}", STR_ENDTAG, "=", STR_FIELDVALUE, "${b}", STR_ENDTAG);

								Match mMatch = Regex.Match(strLine, strSearch);
								string strMatch;
								string strColoredMatch;

								while (Match.Empty != mMatch) 
								{
									strMatch = mMatch.ToString();
									strColoredMatch = Regex.Replace(strMatch, strSearch, strReplace);
									if (Regex.IsMatch(strMatch,strNestedSearch)) 
									{
										strColoredMatch = Regex.Replace(strMatch, strNestedSearch, strNestedReplace);
									}

									//strLine = Regex.Replace(strLine, strMatch, strColoredMatch);
									strLine = strLine.Replace(strMatch, strColoredMatch);
									mMatch = mMatch.NextMatch();
								}
								strLine = Regex.Replace(strLine, strSearch, strReplace);
							}

							// Colorize </asp:>
							strSearch = @"(?i)(?<a></)(?<b>\s?asp:\S*)(?<c>\s?>)";
							strReplace = String.Concat("${a}", STR_TAGNAME, "${b}", STR_ENDTAG, "${c}");
							if (Regex.IsMatch(strLine, strSearch)) 
							{
								strLine = Regex.Replace(strLine, strSearch, strReplace);
							}

							// Colorize multi-line asp tags, fields, and values
							strSearch = @"(?i)(?<a></?)(?<b>\s?asp:\S*)(?<c>.*(?!>))";
							strReplace = String.Concat("${a}", STR_TAGNAME, "${b}", STR_ENDTAG, "${c}");
							if (Regex.IsMatch(strLine,strSearch) &&
								Regex.Match(strLine,strSearch).ToString().IndexOf(">") == -1) 
							{

								string strNestedSearch = @"(?i)(?<a>[^ \f\n\r\t\v=]+\s*)=(?<b>\s*[^\s&)]+)";
								string strNestedReplace = String.Concat(STR_FIELDNAME, "${a}", STR_ENDTAG, "=", STR_FIELDVALUE, "${b}", STR_ENDTAG);

								if (Regex.IsMatch(strLine,strNestedSearch)) 
								{
									strLine = Regex.Replace(strLine, strNestedSearch, strNestedReplace);
								}

								strLine = Regex.Replace(strLine, strSearch, strReplace);
								swColoredCode.Write(strLine + "\n");

								strSearch = "(?<a>(^.*))(?<b>(>))";
								do 
								{
									strLine = srPlainCode.ReadLine();
									strLine = Regex.Replace(strLine, "\t", "    ");
									strLine = Regex.Replace(strLine, "<", "<");
									strLine = Regex.Replace(strLine, ">", ">");
									if (!Regex.IsMatch(strLine, strSearch)) 
									{
										strLine = Regex.Replace(strLine, strNestedSearch, strNestedReplace);
										swColoredCode.Write(strLine + "\n");
									}
								} while (!Regex.IsMatch(strLine, strSearch) && (-1 != srPlainCode.Peek()));

								strLine = Regex.Replace(strLine, strNestedSearch, strNestedReplace);
							}
       
							//colorize begin of tag char(s) "<","</"        
							strSearch = "(?i)(?<a>(<)(?!%)(/|!)?)";
							strReplace = String.Concat(STR_BRACKET, "${a}", STR_ENDTAG);
							if (Regex.IsMatch(strLine, strSearch)) 
							{
								strLine = Regex.Replace(strLine, strSearch, strReplace);
							}
                                    
							// Colorize end of tag char(s) ">","/>"        
							strSearch = "(?i)(?<a>/?(?!%)(>))";
							strReplace = String.Concat(STR_BRACKET, "${a}", STR_ENDTAG);
							if (Regex.IsMatch(strLine, strSearch)) 
							{
								strLine = Regex.Replace(strLine, strSearch, strReplace);
							}
						}
					}
				}
				swColoredCode.Write(strLine + "\n");
			}
			return Format_Util.EnclosePreTags(swColoredCode.ToString());
		}


		/// <summary>
		/// Returns a string of HTML after formatting input with colors used in Visual.NET for C# code.
		/// </summary>
		/// <param name="strCode"> C# code in string format </param>
		public static string ColorCSCode(string strCode) 
		{

			StringReader srPlainCode = new StringReader(strCode);
			StringWriter swColoredCode = new StringWriter();
            
			string strLine;
			string strSearch;
			string strReplace;

			while (-1 != srPlainCode.Peek()) 
			{

				strLine = srPlainCode.ReadLine();

				if ((strLine != null) && (strLine.Length != 0)) 
				{

					// Search for \t and replace it with 4 spaces.
					strSearch = @"(?i)(\t)";
					strReplace = "    " ;
					if (Regex.IsMatch(strLine, strSearch)) 
						strLine = Regex.Replace(strLine, strSearch, strReplace);

					// Search and replace "<" char.
					strSearch = "(?i)(<)";
					strReplace = "<";
					if (Regex.IsMatch(strLine, strSearch))
						strLine = Regex.Replace(strLine, strSearch, strReplace);

					// Single line comment using "//"
					strSearch = @"(?<a>(^\s*))(?<b>(//))(?<c>(.*))" ;
					strReplace = String.Concat("${a}", STR_COMMENT, "${b}${c}", STR_ENDTAG);
					if (Regex.IsMatch(strLine, strSearch)) 
					{
						strLine = Regex.Replace(strLine, strSearch, strReplace);
					} 
					else 
					{
                    
						// Single line comment using /* comment */
						strSearch = @"(?<a>(^\s*))(?<b>(/\*))(?<c>([^(\*/)]*)(\*/))";
						strReplace = String.Concat("${a}", STR_COMMENT, "${b}${c}", STR_ENDTAG);
						if (Regex.IsMatch(strLine, strSearch)) 
						{
							strLine = Regex.Replace(strLine, strSearch, strReplace);
						}
						else 
						{

							// Multi-line comment
							strSearch = @"(?<a>(^\s*)(/\*))";
							if (Regex.IsMatch(strLine,strSearch)) 
							{
								strLine = String.Concat(STR_COMMENT, strLine, STR_ENDTAG, "\n");
								swColoredCode.Write(strLine + "\n");

								strSearch = @"(?<a>(^.*))(?<b>(\*/))";
								do 
								{
									strLine = srPlainCode.ReadLine();
									strLine = Regex.Replace(strLine, "\t", "    ");
									strLine = Regex.Replace(strLine, "<", "<");
									strLine = Regex.Replace(strLine, ">", ">");
									if (!Regex.IsMatch(strLine, strSearch)) 
									{
										swColoredCode.Write( String.Concat(STR_COMMENT, strLine, STR_ENDTAG, "\n") );
									}
								} while (!Regex.IsMatch(strLine, strSearch));

								strLine = String.Concat(STR_COMMENT, strLine, STR_ENDTAG, "\n");
							}
							else 
							{

								// End of statement comments
								strSearch = "(?<x>(^.*))(?<y>(//.*))";
								strReplace = String.Concat("${x}", STR_COMMENT, "${y}", STR_ENDTAG);
								if (Regex.IsMatch(strLine, strSearch) ) 
								{
									strLine = Regex.Replace(strLine, strSearch, strReplace);    
								}

								// If, Else statements
								strSearch = @"(?i)(?<a>((\s|\{|\}|\;){1}|^\\s*))(?<b>(if|#if|else if|else if|#else if|else|#else))(?<c>(\s|\(){1}(.*))";
								strReplace = String.Concat("${a}", STR_CS, "${b}", STR_ENDTAG, "${c}");
								if (Regex.IsMatch(strLine, strSearch)) 
								{
									strLine = Regex.Replace(strLine, strSearch, strReplace);
								}

								// Get, Set, Try, Catch, Finally statements
								strSearch = @"(?i)(?<a>((\s|\}|\;){1}|^\s*))(?<b>(get|set|try|catch|finally))(?<c>(\s|\(|\{){1}(.*))";
								strReplace = String.Concat("${a}", STR_CS, "${b}", STR_ENDTAG, "${c}");
								if (Regex.IsMatch(strLine, strSearch)) 
								{
									strLine = Regex.Replace(strLine, strSearch, strReplace);
								}

								// Special language constructs
								strSearch = @"(?i)(?<a>((\s|\{|\}|\;){1}|^\s*))(?<b>(do while|while|do|while|for each|switch|case|for|with|imports|inherits|implements|using|namespace))(?<c>(\s|\(){1}(.*))";
								strReplace = String.Concat("${a}", STR_CS, "${b}", STR_ENDTAG, "${c}");
								if (Regex.IsMatch(strLine, strSearch)) 
								{
									strLine = Regex.Replace(strLine, strSearch, strReplace);
								}

								// Primitives
								strSearch = @"(?i)(?<a>((\s|\(|\)|\,){1}|^\s*))(?<b>(bool|byte|char|class|double|enum|float|int|long|object|return|short|string|void))(?<c>(\s|\())";
								strReplace = String.Concat("${a}", STR_CS, "${b}", STR_ENDTAG, "${c}");
								if (Regex.IsMatch(strLine, strSearch)) 
								{
									strLine = Regex.Replace(strLine, strSearch, strReplace);
								}

								// this
								strSearch = @"(?i)(?<a>((\s|\{|\;){1}|^\s*))(?<b>(this))(?<c>(\.))";
								strReplace = "${a}" + STR_CS +  "${b}" + STR_ENDTAG + "${c}";
								if (Regex.IsMatch(strLine,strSearch)) 
								{
									strLine = Regex.Replace(strLine, strSearch, strReplace);
								}

								// new
								strSearch = @"(?i)(?<a>((\=|\(|\s){1}|^\s*))(?<b>((new)\s*))";
								strReplace = String.Concat("${a}", STR_CS, "${b}", STR_ENDTAG);
								if (Regex.IsMatch(strLine, strSearch)) 
								{
									strLine = Regex.Replace(strLine, strSearch, strReplace);
								}

								// return
								strSearch = @"(?i)(?<a>((\{|\s|\;){1}|^\s*))(?<b>((return)\s*))";
								strReplace = String.Concat("${a}", STR_CS, "${b}", STR_ENDTAG);
								if (Regex.IsMatch(strLine, strSearch)) 
								{
									strLine = Regex.Replace(strLine, strSearch, strReplace);
								}

								// Declarations
								strSearch = String.Concat(@"(?i)(?<a>(^\s*))(?<b>(((public|private|protected|abstract|sealed|internal|override)(\s+))?",
									@"((abstract|const|event|extern|override|readonly|static|virtual)(\s+))?",
									@"((bool|byte|char|class|double|enum|float|int|long|object|return|short|string|void)(\s+))?))(?<c>(.*))");
								strReplace = String.Concat("${a}", STR_CS, "${b}", STR_ENDTAG, "${c}");
								if (Regex.IsMatch(strLine, strSearch)) 
								{
									// check if match is more than just spaces
									Match mMatch = Regex.Match(strLine, strSearch);
									if (Regex.IsMatch(mMatch.ToString(), @"\S")) 
									{
										strLine = Regex.Replace(strLine, strSearch, strReplace);
									}
								}

							}
						}
					}
				}
				swColoredCode.Write(strLine + "\n");
			}
			return Format_Util.EnclosePreTags(swColoredCode.ToString());
		}
	}

	internal class Format_Util 
	{
        
		public static string EnclosePreTags(string str) 
		{
			return String.Concat("<pre>", str, "</pre>\n");
		}	
		
	}



}



