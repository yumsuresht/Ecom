using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Web;
using System.IO;
using System.Web.Caching;

namespace CSF
{
	/// <summary>
	/// Summary description for TutorialsDB.
	/// </summary>
	public class TutorialsDB
	{

		public SqlDataReader GetFeaturedTutorials ()
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();
			
			// run the stored procedure
			data.RunProc("procGetFeaturedTutorials",out dataReader);

			return dataReader;
		}
		
		
		public SqlDataReader GetCats()
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			// run the stored procedure
			data.RunProc("procGetTutorialCats", out dataReader);

			return dataReader;
		}
		
		public SqlDataReader GetSubCats()
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			// run the stored procedure
			data.RunProc("procGetTutorialSubCats", out dataReader);

			return dataReader;
		}

		public SqlDataReader GetSubList(int catID)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@catID" ,SqlDbType.Int, 4, catID)
			};

			// run the stored procedure
			data.RunProc("procGetSubList", prams, out dataReader);

			return dataReader;
		}

		public SqlDataReader GetIndexByLetter(string szIndex)
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();

			SqlParameter[] prams =
			{                     
				data.MakeInParam("@szIndex" ,SqlDbType.Char, 1, szIndex)
			};

			// run the stored procedure
			data.RunProc("procGetTutorialByLetter", prams, out dataReader);

			return dataReader;
		}
		
		/// <summary>
		/// Displays the latest tutorials, top 20
		/// </summary>
		/// <param name="szIndex"></param>
		/// <returns></returns>
		public SqlDataReader GetLatest()
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();			

			// run the stored procedure
			data.RunProc("procGetLatestTutorials", out dataReader);

			return dataReader;
		}

		/// <summary>
		/// Displays the latest tutorials, top 20
		/// </summary>
		/// <param name="szIndex"></param>
		/// <returns></returns>
		public SqlDataReader GetAll()
		{
			// create data object and params
			SqlDataReader dataReader = null;
   
			// create params for stored procedure call
			Database data = new Database();			

			// run the stored procedure
			data.RunProc("procGetAllTutorials", out dataReader);

			return dataReader;
		}

		public structTutorial GetTutorialFromID(int tutorialID) 
		{
			// we only want to call this code once per request
			if (HttpContext.Current.Items["Tutorial" + tutorialID] != null)
			{
				return (structTutorial) HttpContext.Current.Items["Tutorial" + tutorialID];
			}
			else
			{
				structTutorial tutorial = new structTutorial();

				SqlDataReader dataReader = null;
				Database data = new Database();

				SqlParameter[] prams =
				{
				data.MakeInParam("@TutorialID", SqlDbType.Int, 4, tutorialID)
				};
						  
				data.RunProc("procGetTutorialText", prams, out dataReader); 
				while (dataReader.Read())
				{
					tutorial.Title = dataReader.GetString(0);
					tutorial.Text = dataReader.GetString(1);				

					// store in current context
					HttpContext.Current.Items["Tutorial" + tutorialID] = tutorial;

					return tutorial;
				}

				tutorial.Title = "Tutorial Not Found";
				tutorial.Text = "Tutorial Not Found";

				return tutorial;
			}
			
			
			
						

		}


		public static string getTutorialText(string strFileName)
		{
				
			System.IO.StreamReader sr = System.IO.File.OpenText( Constants.TUTORIAL_ROOT + "\\" + 	strFileName );
			String text = sr.ReadToEnd();
			sr.Close();
			return text;
		}

		public void UpdateTutorialText(int tutorialID, string tutorialText) 
		{
					
			Database data = new Database();

			SqlParameter[] prams =
			{
				data.MakeInParam("@TutorialID", SqlDbType.Int, 4, tutorialID),
				data.MakeInParam("@szText", SqlDbType.NText, 16, tutorialText)
			};
						  
			data.RunProc("procUpdateTutorialText", prams); 									

		}
		

	}

	public struct structTutorial
	{
		public string Title;
		public string Text;
	}
}

