namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;


	/// <summary>
	///		Summary description for SearchTutorials.
	/// </summary>
	public abstract class SearchTutorials : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Repeater rpSearchResults;
		protected System.Web.UI.WebControls.Label lblQueryInfo;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// header contains textbox, click redirects to this page
			// with the query, format query then call search
			if (Request["tbQuery"] != null)
			{
				string strQuery = Request["tbQuery"];
				lblQueryInfo.Text = String.Concat("Search results for ", " '", strQuery, "'");

				//Make sure user does not submit empy queries
				if (strQuery != null && string.Empty != strQuery)
				{
					strQuery = CSF.Search.FormatQeuryString(strQuery);
				
					rpSearchResults.DataSource = CSF.Search.Tutorials(strQuery);
					rpSearchResults.DataBind();

					// log queries to file w/ timestamp
					CSF.Utils.WriteToFile(strQuery + " at " + System.DateTime.Now, @"F:\Inetpub\wwwroot\Members\Main\Search\searchLog.txt");

				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
