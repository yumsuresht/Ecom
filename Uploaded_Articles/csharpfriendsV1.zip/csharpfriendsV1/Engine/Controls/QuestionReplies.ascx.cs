namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for QuestionReplies.
	/// </summary>
	public abstract class QuestionReplies : System.Web.UI.UserControl
	{

		protected System.Web.UI.WebControls.Repeater	rpQuestionAndTitle;
		protected System.Web.UI.WebControls.Repeater	rpQuestionReplies;

		// links to next & prev
		protected System.Web.UI.WebControls.HyperLink lnkPrevious;
		protected System.Web.UI.WebControls.HyperLink lnkNext;
		protected System.Web.UI.WebControls.Literal	  liPagesLink;


		public int iQuestionID;
		
		// page variables
		private int currentPage = 0;
		private int pageCount = 0;
		private int numResults = 0;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				// First time here we want to fetch the first page. All of the
				// other page requests will be handled through the page 
				// navigation button event handlers.
				currentPage = 1;
				BindPagedData();					
								
			}


		}

		private void BindPagedData()
		{
			if (Request["QID"] !=null)
			{
				iQuestionID = Int32.Parse(Request["QID"]);				
							
				if (Request.QueryString["requestedPage"] != null) 
				{
					currentPage = System.Int32.Parse(Request.QueryString["requestedPage"]);
					pageCount = System.Int32.Parse(Request.QueryString["pageCount"]);
				}
				else
					currentPage = 1;				
         
				//display question
				rpQuestionAndTitle.DataSource = CSF.Questions.GetByID(iQuestionID);
				rpQuestionAndTitle.DataBind();

				//replies
				rpQuestionReplies.DataSource = CSF.Questions.GetRepliesByID(iQuestionID,currentPage, CSF.Constants.QUESTIONS_PAGESIZE, ref numResults);
				rpQuestionReplies.DataBind();

				
				// if this is the first time, calculate the total number of pages
				if (!Page.IsPostBack) 
					pageCount = (int)System.Math.Ceiling((double)numResults / CSF.Constants.QUESTIONS_PAGESIZE);
			
				// hide or show navigation buttons
				if (pageCount > 1) 
				{
					// there are multiple pages
					lnkPrevious.Visible = currentPage > 1;
					lnkNext.Visible = currentPage < pageCount;
					
					// individual page links
					liPagesLink.Visible = true;
					System.Text.StringBuilder sbPages = new System.Text.StringBuilder();
					
					string linkUrl = @"<a href=""" + CSF.Constants.ROOT_URL + "/Members/Main/Question/replies.aspx?QID=" + iQuestionID + "&requestedPage=";
					string linkUrlEnd = "&pageCount=" + pageCount + @""">";

					for(int x = 1; x <= pageCount; x++)
					{
						if(currentPage == x)
							sbPages.Append("[" + x + "</a>]&nbsp;");
						else
							sbPages.Append("[" + linkUrl + x + linkUrlEnd + x + "</a>]&nbsp;");
					}
					liPagesLink.Text = sbPages.ToString();


					lnkPrevious.NavigateUrl = CSF.Constants.ROOT_URL+ "/Members/Main/Question/replies.aspx?QID=" + iQuestionID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					lnkNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Question/replies.aspx?QID=" + iQuestionID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
				}
				else 
				{
					// there is only one page, hide both buttons
					lnkPrevious.Visible = lnkNext.Visible = false;
					lnkPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Question/replies.aspx?QID=" + iQuestionID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					lnkNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Question/replies.aspx?QID=" + iQuestionID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
				}
				
								
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
