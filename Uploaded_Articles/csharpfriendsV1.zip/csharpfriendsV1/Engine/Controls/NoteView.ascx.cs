namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.SqlClient;

	/// <summary>
	///		Summary description for NoteView.
	/// </summary>
	public abstract class NoteView : System.Web.UI.UserControl
	{

		protected System.Web.UI.WebControls.Label szFrom;
		protected System.Web.UI.WebControls.Label szTo;
		protected System.Web.UI.WebControls.Label szSubject;
		protected System.Web.UI.WebControls.Label szDate;
		protected System.Web.UI.WebControls.Label szMessage;

		public string NoteID;				

		private void Page_Load(object sender, System.EventArgs e)
		{
			int noteID = 0;

			if(Request.QueryString["noteID"] !=null)
			{
				noteID = Int32.Parse(Request["noteID"]);
			
				//if(noteID >0)
				//{
				CSF.NotesDB note = new CSF.NotesDB();
				
				//should we check for logged in?

				SqlDataReader reader = note.GetNote(Int32.Parse(Page.User.Identity.Name), noteID);

				while (reader.Read())
				{
					NoteID = reader.GetSqlInt32(0).ToString();
					szFrom.Text = reader.GetString(2);
					szTo.Text = reader.GetString(3);
					szSubject.Text = reader.GetString(4);
					szDate.Text =  (reader.GetSqlDateTime(5)).ToString();
					szMessage.Text = reader.GetString(6);
				}

				reader.Close();
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
