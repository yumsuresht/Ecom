namespace CSF.Controls
{
	using System;
	using System.Collections;
	using System.ComponentModel;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.Security;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Configuration;

	/// <summary>
	///		Summary description for Login.
	/// </summary>
	public abstract class Login : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label Message;  //failed login
		protected System.Web.UI.WebControls.TextBox userName;
		protected System.Web.UI.WebControls.TextBox password;
		protected System.Web.UI.WebControls.Button LoginBtn;

		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedIn;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedOut;
		
		protected System.Web.UI.WebControls.Label WelcomeMsg; //random quote

		protected System.Web.UI.WebControls.TextBox txtInvite;
		protected System.Web.UI.WebControls.RegularExpressionValidator regexInvite;
		protected System.Web.UI.WebControls.Button btnInviteSend;

		protected System.Web.UI.WebControls.Literal liMemberPoints;

		//keep signed in
		protected System.Web.UI.WebControls.CheckBox chkRememberPassword;

		public int iNewStatus = 0;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			ShowLoggedInArea();
		}
	

		// display different items if person is logged in or not
		private void ShowLoggedInArea()
		{
			// check to see if we have a sessionid(formsAuthentication)
			bool loggedIn = false;
			
			if (Page.User.Identity.IsAuthenticated)
			{
				
				loggedIn = true;
				
				// Grab users points
				liMemberPoints.Text = CSF.UsersDB.GetUserPoints(Int32.Parse(Page.User.Identity.Name)).ToString();

				// Grab note status - new notes / none

				iNewStatus = CSF.UsersDB.GetNoteStatus(Int32.Parse(Page.User.Identity.Name));
				
			}

			// show or hide login buttons
			areaLoggedIn.Visible = loggedIn ? true : false;
			areaLoggedOut.Visible = loggedIn ? false : true;
		}

		

		


		public void LoginBtn_Click(Object sender, EventArgs e)
		{

			// Only attempt a login if all form fields on the page are valid
			if (Page.IsValid == true) 
			{

				// Attempt to Validate User Credentials using CustomersDB
				CSF.UsersDB user = new CSF.UsersDB();
				CSF.UserDetails myUser = user.Login(userName.Text, password.Text, CSF.Constants.PTS_LOGIN);

				if (myUser != null) 
				{

					FormsAuthentication.SetAuthCookie(myUser.userID.ToString(),chkRememberPassword.Checked);
					
					// Cookie with User Name
					if (!chkRememberPassword.Checked)
					{
						// Store the user's fullname in a cookie for personalization purposes
						Response.Cookies["csf_szUserName"].Value = myUser.szUserName;
					}
					else
					{
						// Persist the cookie also up until 12:00AM since
						// we need to allow user to rec points for loggin in
						Response.Cookies["csf_szUserName"].Value = myUser.szUserName;
						Response.Cookies["csf_szUserName"].Expires = DateTime.Now + new TimeSpan(365,0,0,0);
					
					}
					
					Response.Redirect(CSF.Constants.ROOT_URL + "/index.aspx");
						
				}
				else 
				{
					Message.Text = "Login Failed!";					
				}

			}
		}
		
		public void btnInvite_Click(object sender, EventArgs e)
		{
			
			//regexInvite.ValidationExpression = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$ ";
			//SmtpMail.Send(tbYourEmail.Text, tbFriendEmail.Text, strSubject, strBody);
			if (Page.IsValid == true) 
			{
				try
				{
					System.Web.Mail.SmtpMail.Send(CSF.Constants.JOIN_EMAIL, txtInvite.Text, "Check out csharpfriends.com!", 
						"Greetings!\nYour friend " + Request.Cookies["csf_szUserName"].Value + "," + CSF.Constants.InviteEmailBody );
				}
				catch
				{
					System.Web.Mail.SmtpMail.Send(CSF.Constants.JOIN_EMAIL, txtInvite.Text, "Check out csharpfriends.com!", 
						"Greetings!\nYour friend " + "CSF" + "," + CSF.Constants.InviteEmailBody );
				}
			
				Response.Redirect(CSF.Constants.ROOT_URL);
			}		
			

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
