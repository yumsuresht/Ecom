namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for Registeration.
	/// </summary>
	public abstract class Registeration : System.Web.UI.UserControl
	{

		protected System.Web.UI.WebControls.TextBox szUserName;
		protected System.Web.UI.WebControls.TextBox szFName;
		protected System.Web.UI.WebControls.TextBox szLName;
		protected System.Web.UI.WebControls.TextBox szEmail;
		protected System.Web.UI.WebControls.TextBox szPassword;
		protected System.Web.UI.WebControls.TextBox iAge;
		protected System.Web.UI.WebControls.TextBox szEducation;
		protected System.Web.UI.WebControls.TextBox szCountry;
		protected System.Web.UI.WebControls.TextBox szJob;
		protected System.Web.UI.WebControls.TextBox szSkills;
		protected System.Web.UI.WebControls.TextBox szFavLang;
		protected System.Web.UI.WebControls.TextBox szMyComputer;


		protected System.Web.UI.WebControls.Button AddUserBtn;
		protected System.Web.UI.WebControls.RequiredFieldValidator rfvUSERNAME;
		protected System.Web.UI.WebControls.RequiredFieldValidator rfvFNAME;
		protected System.Web.UI.WebControls.RequiredFieldValidator rfvLName;
		protected System.Web.UI.WebControls.RegularExpressionValidator rfvEmail;
		protected System.Web.UI.WebControls.RegularExpressionValidator regUserName;
		
		protected System.Web.UI.WebControls.ValidationSummary valSummary;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvEmail;
		protected System.Web.UI.WebControls.RequiredFieldValidator ReqfvPwd1;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvPwd2;
		protected System.Web.UI.WebControls.CompareValidator comparePwd1AND2;
		protected System.Web.UI.WebControls.RegularExpressionValidator regPassword;
		protected System.Web.UI.WebControls.RegularExpressionValidator regAge;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvAge;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvEducation;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvCountry;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvJob;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvSkills;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvFavLang;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvMyComputer;
		//protected System.Web.UI.WebControls.TextBox reqfvJob;
		protected System.Web.UI.WebControls.TextBox szPasswordConfirm;
		
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		public void AddUserBtn_Click(Object sender, EventArgs e)
		{
			//From http://regexlib.com/Default.aspx
			//rfvEmail.ValidationExpression = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
			//regUserName.ValidationExpression = @"^\d{3-15}[a-zA-Z0-9]+$"; //="^\d{5}
			//regUserName.ValidationExpression = @"[a-zA-Z0-9][\w\-]{1-13}[a-zA-Z0-9]";
			// Only attempt a login if all form fields on the page are valid
			
			if (Page.IsValid == true) 
			{
				// Generate Confirmation GUID
				string gConfirm = System.Guid.NewGuid().ToString("N");


				// Attempt to Validate User Credentials using CustomersDB
				CSF.UsersDB newUser = new CSF.UsersDB();
				newUser.AddUser(szUserName.Text,szFName.Text, szLName.Text, szEmail.Text,szPassword.Text,
					Int32.Parse(iAge.Text), szEducation.Text, szCountry.Text, szJob.Text, szSkills.Text,
					szFavLang.Text, szMyComputer.Text, gConfirm,CSF.Constants.NEW_USER_NOTE_BODY);
				
				CSF.UsersDB.ConfirmAccount(szUserName.Text, szEmail.Text, gConfirm);		

				if( "true" == System.Configuration.ConfigurationSettings.AppSettings["ReportNewUsers"].ToLower())
				{
					CSF.Utils.EmailMe("Reg Conf",szUserName.Text);
				}

				Response.Redirect("Registered.aspx");
								
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
