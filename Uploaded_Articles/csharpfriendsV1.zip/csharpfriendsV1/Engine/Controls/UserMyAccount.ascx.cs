namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.SqlClient;

	/// <summary>
	///		Summary description for UserMyAccount.
	/// </summary>
	public abstract class UserMyAccount : System.Web.UI.UserControl
	{
		//protected System.Web.UI.WebControls.TextBox szUserName;
		protected System.Web.UI.WebControls.TextBox szFName;
		protected System.Web.UI.WebControls.TextBox szLName;
		//protected System.Web.UI.WebControls.TextBox szEmail;
		//protected System.Web.UI.WebControls.TextBox szPassword;
		protected System.Web.UI.WebControls.TextBox iAge;
		protected System.Web.UI.WebControls.TextBox szEducation;
		protected System.Web.UI.WebControls.TextBox szCountry;
		protected System.Web.UI.WebControls.TextBox szJob;
		protected System.Web.UI.WebControls.TextBox szSkills;
		protected System.Web.UI.WebControls.TextBox szFavLang;
		protected System.Web.UI.WebControls.TextBox szMyComputer;
		
		protected System.Web.UI.WebControls.Button UpdateUserBtn;
		//protected System.Web.UI.WebControls.Button AddUserBtn;
		//protected System.Web.UI.WebControls.RequiredFieldValidator rfvUSERNAME;
		protected System.Web.UI.WebControls.RequiredFieldValidator rfvFNAME;
		protected System.Web.UI.WebControls.RequiredFieldValidator rfvLName;
		//protected System.Web.UI.WebControls.RegularExpressionValidator rfvEmail;
		//protected System.Web.UI.WebControls.RegularExpressionValidator regUserName;
		
		protected System.Web.UI.WebControls.ValidationSummary valSummary;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvAge;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvEducation;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvCountry;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvJob;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvSkills;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvFavLang;
		protected System.Web.UI.WebControls.RequiredFieldValidator reqfvMyComputer;
		//protected System.Web.UI.WebControls.RequiredFieldValidator reqfvEmail;
		//protected System.Web.UI.WebControls.RequiredFieldValidator ReqfvPwd1;
		//protected System.Web.UI.WebControls.RequiredFieldValidator reqfvPwd2;
		//protected System.Web.UI.WebControls.CompareValidator comparePwd1AND2;
		//protected System.Web.UI.WebControls.RegularExpressionValidator regPassword;
		protected System.Web.UI.WebControls.RegularExpressionValidator regAge;
		//protected System.Web.UI.WebControls.TextBox szPasswordConfirm;

		private void Page_Load(object sender, System.EventArgs e)
		{
			
			if(!Page.IsPostBack)
			{
				CSF.UsersDB user = new CSF.UsersDB();

				SqlDataReader reader = user.GetUserInfo(Int32.Parse(Page.User.Identity.Name));
			 
				while(reader.Read())
				{
					szFName.Text = reader.GetString(0);
					szLName.Text = reader.GetString(1);
					iAge.Text = reader.GetInt32(2).ToString();
					szEducation.Text = reader.GetString(3);
					szCountry.Text = reader.GetString(4);
					szJob.Text = reader.GetString(10);
					szSkills.Text = reader.GetString(11);
					szFavLang.Text = reader.GetString(12);
					szMyComputer.Text = reader.GetString(13);

				}
			}
			
		
				
		}

		public void UpdateUserBtn_Click(object sender, EventArgs e)
		{
			if(Page.IsValid)
			{
				CSF.UsersDB user = new CSF.UsersDB();
			
				user.UpdateUserInfo(Int32.Parse(Page.User.Identity.Name), szFName.Text,szLName.Text,
					Int32.Parse(iAge.Text),	szEducation.Text, szCountry.Text, szJob.Text, szSkills.Text,
					szFavLang.Text, szMyComputer.Text);
				Response.Redirect(CSF.Constants.ROOT_URL);
			}
		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.UpdateUserBtn.Click += new System.EventHandler(this.UpdateUserBtn_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}

