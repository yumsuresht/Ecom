namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Configuration;
	using System.Data.SqlClient;

	/// <summary>
	///		Summary description for ForumThreads.
	/// </summary>
	public abstract class ForumThreads : System.Web.UI.UserControl
	{

		protected System.Web.UI.WebControls.Button AddThread;

		protected System.Web.UI.WebControls.Label lblMessage;


		protected System.Web.UI.WebControls.Repeater threadList;
		
		protected System.Web.UI.WebControls.HyperLink lnkPrevious;
		protected System.Web.UI.WebControls.HyperLink lnkNext;
		
		protected System.Web.UI.WebControls.Label hdnFormForumID;
		protected System.Web.UI.WebControls.Label hdnFormMessageID;
		
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedIn;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedOut;

		protected System.Web.UI.WebControls.LinkButton lbSubscribe;

		int forumID;
		int messageID;

		// page variables
		private int currentPage = 0;
		private int pageCount = 0;
		private int numResults = 0;

		
		//sets the lblMessage to the original forum message to which all the replies
		//belong to
		private void getMessage(int forumID,int messageID)
		{
			CSF.ForumsDB message = new CSF.ForumsDB();
			SqlDataReader reader = message.GetForumMessage(forumID, messageID);
			
			string strMessage = "";
			
			// display current message so each page will have original message
			// on each screen
			while (reader.Read())
			{

				strMessage = "<b>" + reader.GetString(2).ToString() + "</b>&nbsp;&nbsp;";
				strMessage = strMessage + @"Thread By:&nbsp;<a href=""../Notes/new.aspx?szUN=" + reader.GetSqlString(1).ToString() + @"""><img height=""11"" src=""" + CSF.Constants.ROOT_URL + @"/Members/images/email.gif"" width=""20"" border=""0"" alt=""Send me a Note!""></a>&nbsp;<a href=""javascript:showProfile('" + reader.GetSqlString(1).ToString() + "','" + reader.GetSqlInt32(0).ToString() + @"', '" + CSF.Constants.ROOT_URL + @"');""  class=""forumalias"">"  + reader.GetSqlString(1).ToString() + @"</a>&nbsp;on&nbsp;" + reader.GetDateTime(4).ToString() + "<BR><br>";
				strMessage = strMessage + reader.GetString(3).ToString();
				
			}

			lblMessage.Text = strMessage;
			
			
		
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			
			
			if(!IsPostBack)
			{
				// First time here we want to fetch the first page. All of the
				// other page requests will be handled through the page 
				// navigation button event handlers.
				currentPage = 1;
				BindPagedData();	
				ShowLoggedInArea();
								
			}
		}
		
		//cutom paging
		private void BindPagedData()
		{
			

			if ((Request.QueryString["forumID"] !=null) && (Request.QueryString["messageID"] !=null))
			{
				forumID = Int32.Parse(Request["forumID"]);
				messageID = Int32.Parse(Request["messageID"]);

				getMessage(forumID, messageID);
			
				hdnFormForumID.Text = "<input type=hidden name=forumID value=" + forumID + ">";
				hdnFormMessageID.Text = "<input type=hidden name=messageID value=" + messageID + ">";

						
				// pull the values off the query string
				if (Request.QueryString["requestedPage"] != null) 
				{
					currentPage = System.Int32.Parse(Request.QueryString["requestedPage"]);
					pageCount = System.Int32.Parse(Request.QueryString["pageCount"]);
				}
				else
					currentPage = 1;
			
				// Obtain list of all the threads
				CSF.ForumsDB messages = new CSF.ForumsDB();
         
				//threadList.DataSource = messages.GetForumThreads(forumID,messageID);
				threadList.DataSource = messages.GetForumThreadsByPage(forumID, messageID, currentPage,CSF.Constants.FORUM_THREAD_PAGESIZE, ref numResults);
				threadList.DataBind();
				
				// if this is the first time, calculate the total number of pages
				if (!Page.IsPostBack) 
					pageCount = (int)System.Math.Ceiling((double)numResults / CSF.Constants.FORUM_THREAD_PAGESIZE);
			
				// hide or show navigation buttons
				if (pageCount > 1) 
				{
					// there are multiple pages
					lnkPrevious.Visible = currentPage > 1;
					lnkNext.Visible = currentPage < pageCount;
					lnkPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/forums/Threads.aspx?forumID=" + forumID + "&messageID=" + messageID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					lnkNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/forums/Threads.aspx?forumID=" + forumID + "&messageID=" + messageID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
				}
				else 
				{
					// there is only one page, hide both buttons
					lnkPrevious.Visible = lnkNext.Visible = false;
					lnkPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/forums/Threads.aspx?forumID=" + forumID + "&messageID=" + messageID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					lnkNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/forums/Threads.aspx?forumID=" + forumID + "&messageID=" + messageID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
				}

				
			}
		}
		// display different items if person is logged in or not
		private void ShowLoggedInArea()
		{
			// check to see if we have a sessionid(formsAuthentication)
			bool loggedIn = false;
			
			if (Page.User.Identity.IsAuthenticated)
			{
				loggedIn = (Page.User.Identity.Name != null) ? true : false;
				
			}

			// show or hide login buttons
			areaLoggedIn.Visible = loggedIn ? true : false;
			areaLoggedOut.Visible = loggedIn ? false : true;
		}

		public void AddThreadBtn_Click(Object sender, EventArgs e)
		{
			if(Page.IsValid == true)
			{
						
				if ( (Page.User.Identity.IsAuthenticated) && 
					(Request.QueryString["forumID"] !=null) &&
					(Request.QueryString["messageID"] !=null) )
				{
					int forumID =  Int32.Parse(Request.Form["forumID"]);
					int messageID =  Int32.Parse(Request.Form["messageID"]);
					
					string NewThread = (string)(Request["NewThread"]);
					
					CSF.ForumsDB thread = new CSF.ForumsDB();
					//thread.PutForumThreads(Int32.Parse(forumID),Int32.Parse(messageID),Server.HtmlEncode(commentThread.Text));
					thread.PutForumThreads(Int32.Parse(Page.User.Identity.Name), forumID, messageID, NewThread, CSF.Constants.PTS_FORUM_REPLY);

					//Response.Redirect("Threads.aspx?forumID=" + forumID + "&messageID=" + messageID);

					// send user back to page after posting, according to 
					// forum/message/page
					Response.Redirect(Request.RawUrl);
				}
		
			
			}
		
		}

		public void lbSubscribe_Click(object sender, EventArgs e)
		{
			CSF.ForumsDB forum = new CSF.ForumsDB();
			forum.PutMessageSubscription(Int32.Parse(Page.User.Identity.Name), Int32.Parse(Request["messageID"]));
			Response.Redirect("threads.aspx?forumID=" + Request["forumID"] + "&messageID=" + Request["messageID"]);
		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
