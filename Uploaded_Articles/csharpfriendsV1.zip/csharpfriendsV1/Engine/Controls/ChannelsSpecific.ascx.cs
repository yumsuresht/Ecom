namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for ChannelsSpecific.
	/// </summary>
	public abstract class ChannelsSpecific : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Repeater channel;

		int channelID;

		

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Request.QueryString["channelID"] !=null)
				//if (Int32.Parse(Request["channelID"]) > 0)
			{
				channelID = Int32.Parse(Request["channelID"]);
							
				// grab all channel articles into a repeater
				CSF.ChannelsDB channelIndex = new CSF.ChannelsDB();
				channel.DataSource = channelIndex.GetChannelArticles(channelID);
				channel.DataBind();
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
