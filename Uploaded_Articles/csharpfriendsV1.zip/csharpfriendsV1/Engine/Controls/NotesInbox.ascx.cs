namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Web;
	using System.Web.UI.WebControls;	
	using System.Data.SqlClient;
	using System.Configuration;

	/// <summary>
	///		Summary description for NotesInbox.
	/// </summary>
	public abstract class NotesInbox : System.Web.UI.UserControl
	{

		//Controls
		protected System.Web.UI.WebControls.Repeater noteList;
		protected System.Web.UI.WebControls.HyperLink lnkPrevious;
		protected System.Web.UI.WebControls.HyperLink lnkNext;
		protected System.Web.UI.WebControls.ImageButton btnDeleteNotes;
		
		//Page variables
		private int numResults = 0;
		
		public int pageSize = CSF.Constants.NOTES_PAGESIZE;
		
		private int totalRows;  
		public int pageCount = 0;
		public int cntRows = 0;
		public int currentPage = 0;


		//Display appriopriate color code depending on note status
		public string checkNoteStatus(string bNew)
		{
			if(bNew.ToLower() == "true" )

				return "#FFF7E5";  //yellow

			else

				return "#ffffff";  
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				currentPage = 1;
				BindPagedData();	
			}
		}

		private void BindPagedData()
		{
			bool hasUserPaged = false;
			
			if (Page.User.Identity.IsAuthenticated)
			{
				// pull the values off the query string
				if ( (Request.QueryString["requestedPage"] != null) && 
					(Request.QueryString["pageCount"] != null)&&
					(Request.QueryString["cntRows"] != null)  )
				{
					currentPage = System.Int32.Parse(Request.QueryString["requestedPage"]);
					pageCount = System.Int32.Parse(Request.QueryString["pageCount"]);
					cntRows = totalRows = System.Int32.Parse(Request.QueryString["cntRows"]);
					
					cntRows = cntRows - ( (currentPage-1) * CSF.Constants.NOTES_PAGESIZE);
					//Response.Write("<br>Revised: " + cntRows);
					hasUserPaged = true;
				}
				else
					currentPage = 1;

				// Obtain list of notes
				CSF.NotesDB notes = new CSF.NotesDB();
			
				SqlDataReader reader = notes.GetNotesByPage( Int16.Parse(Page.User.Identity.Name), currentPage, CSF.Constants.NOTES_PAGESIZE, ref numResults); 
				noteList.DataSource = reader;
				
				/* If the user has paged, don't need to get a new count of notes.
				   What happens if somone sends a new note while he is viewing notes?
				*/ 
				if (hasUserPaged == false)
					totalRows = cntRows = reader.RecordsAffected;
				
				/*If the rows are more than pagedSize, we only display pageSize so set
				 * cntRows to equal that value
				*/
				if (cntRows > CSF.Constants.NOTES_PAGESIZE)
				{
					cntRows = CSF.Constants.NOTES_PAGESIZE;
				}
								
				noteList.DataBind();
				reader.Close();
							
				// if this is the first time, calculate the total number of pages
				if (!Page.IsPostBack) 
					pageCount = (int)System.Math.Ceiling((double)numResults / CSF.Constants.NOTES_PAGESIZE);
			
				// hide or show navigation buttons
				if (pageCount > 1) 
				{
					// there are multiple pages
					lnkPrevious.Visible = currentPage > 1;
					lnkNext.Visible = currentPage < pageCount;
					lnkPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/notes/index.aspx?requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount + "&cntRows=" + totalRows;
					lnkNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/notes/index.aspx?requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount + "&cntRows=" + totalRows;
				}
				else 
				{
					// there is only one page, hide both buttons
					lnkPrevious.Visible = lnkNext.Visible = false;
					lnkPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/notes/index.aspx?requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount + "&cntRows=" + totalRows;
					lnkNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/notes/index.aspx?requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount + "&cntRows=" + totalRows;
				}
				
				
			}
		}

		private void btnDeleteNotes_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			string szWhereClause = "";

			//Ensure user selected some
			if (Request.Form["noteID"] != null)
			{
				//Returns a comma seperated string eg. 33,22,432,234
				//Browser rec. noteID=234&noteID=32&... IIS parses it as one thing and
				//forms a Comma-seperated list
				szWhereClause = Request.Form["noteID"];
								
				CSF.NotesDB deleteNotes = new CSF.NotesDB();
				deleteNotes.DeleteNotes(Int32.Parse(Context.User.Identity.Name),szWhereClause);
				
				Response.Redirect("index.aspx");
			}
			else
			{
				Response.Redirect("index.aspx");
			}
											  
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
			this.btnDeleteNotes.Click += new System.Web.UI.ImageClickEventHandler(this.btnDeleteNotes_Click);
		}
		#endregion
	}
}
