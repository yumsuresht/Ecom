namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.SqlClient;
	using System.Collections;

	/// <summary>
	///		Summary description for Tutorials.
	/// </summary>
	public abstract class Tutorials : System.Web.UI.UserControl
	{

		protected System.Web.UI.WebControls.Label lblTOC;
		

		public class tutCategories
		{
			private int catID;
			private string category;

			public int CatID
			{
				get { return catID; }
				set { catID = value; }  
			}

			public string Category
			{
				get { return category; }
				set { category = value; }  
			}
		}
		public class tutSubCats
		{
			private int catID;
			private int subID;
			private string szSubCat;

			public int CatID
			{
				get { return catID;}
				set { catID = value;}
			}
			public int SubID
			{
				get { return subID;}
				set { subID = value;}
			}
			public string SubCat
			{
				get { return szSubCat;}
				set { szSubCat = value;}
			}
            
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			
			
			CSF.TutorialsDB tut = new CSF.TutorialsDB();
			
			int index = 0;
			
			// CATEGORIES INIT
			tutCategories[] cats = new tutCategories[27];
			SqlDataReader  reader = tut.GetCats();
			
			while (reader.Read())
			{
				//Response.Write (reader.GetInt32(0));
				cats[index] = new tutCategories();
				cats[index].CatID = reader.GetInt32(0);
				cats[index].Category = reader.GetString(1);
				index++;
			
			}
			//for (int x = 0; x < 27; x++)
			//Response.Write (cats[x].CatID + cats[x].Category +"<br>");

			// SUB CAT INIT
			tutSubCats[] subs = new tutSubCats[79];
			reader.Close();
			reader = tut.GetSubCats();
			//SqlDataReader  reader2 = tut.GetSubCats();
			index = 0;
			while (reader.Read())
			{
				subs[index] = new tutSubCats();
				subs[index].CatID = reader.GetInt32(0);
				subs[index].SubID = reader.GetInt32(1);
				subs[index].SubCat = reader.GetString(2);
				index++;
			}
			//for (int y = 0; y < 79; y++)
			//	Response.Write ( subs[y].SubID + subs[y].SubCat +"<br>");

			int rowCounter = 0;
			string strOutput = "";  //assign to label after construction
			
			strOutput += "<table width=100%><tr><td>";
			strOutput += "<table width=100%>";
			for (int x = 0; x < 27; x++)
			{
									
				strOutput += "<tr><td><br><a href=www.help.com CLASS=mchanneltitle>" + cats[x].Category + "</a>" + "<br>";
				for (int y = 0; y < 79; y++)
				{
					if (cats[x].CatID == subs[y].CatID)
						//strOutput += "<span CLASS=mchanneltxt>" + subs[y].SubCat + " ,";
						strOutput += "<a href=www.cnet.com CLASS=mchanneltxt>" + subs[y].SubCat + "</a> ,";
				
				}
				strOutput += "</td></tr>";
				rowCounter++;
				if (rowCounter == 10)
					strOutput += "</table></td><td><table width=100%>";
			}
			if ( rowCounter != 10)
				strOutput += "</table>";
			strOutput += "</td></tr></table>";
			
			
			lblTOC.Text = strOutput;

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
