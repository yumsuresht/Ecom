namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Web;	
	using System.Data.SqlClient;

	/// <summary>
	///		Summary description for NoteReply.
	/// </summary>
	public abstract class NoteReply : System.Web.UI.UserControl
	{

		protected System.Web.UI.WebControls.TextBox szTo;
		protected System.Web.UI.WebControls.TextBox szCC;
		protected System.Web.UI.WebControls.TextBox szBCC;
		protected System.Web.UI.WebControls.TextBox szSubject;
		protected System.Web.UI.WebControls.TextBox szMessage;

		protected System.Web.UI.WebControls.ImageButton btnNoteSend;
		

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
			{
				getNote();
			}
		}

		public void getNote()
		{
			int noteID = 0;
			int checkForward = 0;

			if(Request.QueryString["noteID"] !=null)
				noteID = Int32.Parse(Request["noteID"]);

			if(Request.QueryString["forward"] !=null)
				checkForward = Int32.Parse(Request["forward"]);
			
			if(noteID >0)
			{
				CSF.NotesDB note = new CSF.NotesDB();
				
				//should we check for logged in?

				SqlDataReader reader = note.GetNote(Int32.Parse(Page.User.Identity.Name), noteID);

				while (reader.Read())
				{
					if (checkForward > 0)
					{
						szTo.Text = "";
					}
					else
					{
						szTo.Text = reader.GetString(2);
					}
					
					szSubject.Text = "RE: " + reader.GetString(4);
					szMessage.Text = "---Original Message was " + "\n" + reader.GetString(6);
				}

				reader.Close();
			}
		}

		//public void SendNoteBtn_Click(Object sender, EventArgs e)
		private void btnSendNote_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			if(Page.IsValid == true)
			{
				if (Page.User.Identity.IsAuthenticated)
				{
					CSF.NotesDB newNote = new CSF.NotesDB();

					//string NewThread = (string)(Request["NewThread"]);
					
					
					szTo.Text = szTo.Text;
					szCC.Text = szCC.Text;
					szBCC.Text = szBCC.Text;
					szSubject.Text = szSubject.Text;
					szMessage.Text = szMessage.Text;
					/*
					Response.Write (szTo.Text + "<br>");
					Response.Write (szSubject.Text + "<br>");
					Response.Write (szMessage.Text + "<br>");
					Response.End();
					*/
					
					/*
					string CC = (string)(Request["szCC"]);
					string BCC = (string)(Request["szBCC"]);
					string Subject = (string)(Request["szSubject"]);
					string Message = (string)(Request["szMessage"]);
					*/
					
					int bPass = 0;					
					
					bPass = newNote.PutNote(Int32.Parse(Page.User.Identity.Name),szTo.Text, szCC.Text, szBCC.Text, szSubject.Text, szMessage.Text);
					//Response.Write (bPass);
					//Response.End();
					
					Response.Redirect("sent.aspx?verify=" + bPass);
				}
		
			
			}
		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnNoteSend.Click += new System.Web.UI.ImageClickEventHandler(this.btnSendNote_Click);
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
