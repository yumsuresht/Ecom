namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.SqlClient;
	using System.Configuration;	

	/// <summary>
	///		Summary description for ChannelResponses.
	/// </summary>
	public abstract class ChannelResponses : System.Web.UI.UserControl
	{

		protected System.Web.UI.WebControls.Repeater list;		

		protected System.Web.UI.WebControls.HyperLink hlPrevious;
		protected System.Web.UI.WebControls.HyperLink hlNext;
		protected System.Web.UI.WebControls.HyperLink hlPrevious2;
		protected System.Web.UI.WebControls.HyperLink hlNext2;
		
		protected System.Web.UI.WebControls.Label hdnFormArticleID;
		protected System.Web.UI.WebControls.Button AddReply;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedIn;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedOut;

		int articleID;
		
		// page variables
		private int currentPage = 0;
		private int pageCount = 0;
		private int numResults = 0;				
		

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				// First time here we want to fetch the first page. All of the
				// other page requests will be handled through the page 
				// navigation button event handlers.
				currentPage = 1;
				BindPagedData();						
				ShowLoggedInArea();
								
			}
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		// custom paging
		private void BindPagedData()
		{
			if (Request.QueryString["articleID"] !=null)
			{
				articleID = Int32.Parse(Request.QueryString["articleID"]);
			
				//add a else clause for default article?
				//if (articleID > 0)
				//{
				hdnFormArticleID.Text = "<input type=hidden name=articleID value=" + articleID + ">";	

				// pull the values off the query string
				if (Request.QueryString["requestedPage"] != null) 
				{
					currentPage = System.Int32.Parse(Request.QueryString["requestedPage"]);
					pageCount = System.Int32.Parse(Request.QueryString["pageCount"]);
				}
				else
					currentPage = 1;
				
				
				// get page of data and bind to list			
				CSF.ArticlesDB replies = new CSF.ArticlesDB();
								
				SqlDataReader reader = replies.GetArticleRepliesByPage(articleID,currentPage, CSF.Constants.ARTICLE_REPLIES_PAGESIZE, ref numResults);
				list.DataSource = reader;
				list.DataBind();
				reader.Close();

				// if this is the first time, calculate the total number of pages
				if (!Page.IsPostBack) 
					pageCount = (int)System.Math.Ceiling((double)numResults / CSF.Constants.ARTICLE_REPLIES_PAGESIZE);
			
				// hide or show navigation buttons
				if (pageCount > 1) 
				{
					// there are multiple pages
					hlPrevious2.Visible = currentPage > 1;
					hlPrevious.Visible = currentPage > 1;
					hlNext2.Visible = currentPage < pageCount;
					hlNext.Visible = currentPage < pageCount; 

					hlPrevious2.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Channels/article.aspx?articleID=" + articleID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					hlPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Channels/article.aspx?articleID=" + articleID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					hlNext2.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Channels/article.aspx?articleID=" + articleID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;					
					hlNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Channels/article.aspx?articleID=" + articleID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
				}
				else 
				{
					// there is only one page, hide both buttons
					hlPrevious2.Visible = hlNext2.Visible = false;
					hlPrevious.Visible = hlNext.Visible = false;

					hlPrevious2.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Channels/article.aspx?articleID=" + articleID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					hlPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Channels/article.aspx?articleID=" + articleID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					hlNext2.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Channels/article.aspx?articleID=" + articleID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;					
					hlNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/Channels/article.aspx?articleID=" + articleID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
				}


			}
			
		}

		// display different items if person is logged in or not
		private void ShowLoggedInArea()
		{
			// check to see if we have a sessionid(formsAuthentication)
			bool loggedIn = false;
			
							
			if (Page.User.Identity.IsAuthenticated)
				//if (Request.IsAuthenticated == true)
			{
				loggedIn = (Page.User.Identity.Name != null) ? true : false;
				
			}

			// show or hide login buttons
			areaLoggedIn.Visible = loggedIn ? true : false;
			areaLoggedOut.Visible = loggedIn ? false : true;
		}

		public void AddReplyBtn_Click(Object sender, EventArgs e)
		{
			
			//ensure user is logged in to post
			if ( (Page.User.Identity.IsAuthenticated) &&
				(Request["articleID"] !=null) && 
				(Request["NewReply"] !=null) )

			{
				int articleID =  Int32.Parse(Request.Form["articleID"]);
				string NewReply = (string)(Request["NewReply"]);
																	
				CSF.ArticlesDB reply = new CSF.ArticlesDB();
				
				reply.PutArticleReply(Int32.Parse(Page.User.Identity.Name),articleID,NewReply, CSF.Constants.PTS_ARTICE_POST);
				Response.Redirect("article.aspx?articleID=" + articleID);
			}
			else
			{
				//not logged in, display msg
				areaLoggedOut.Visible = true;
				areaLoggedIn.Visible = false;
			}
			
			
		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
