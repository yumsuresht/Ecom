namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for ForumMessages.
	/// </summary>
	public abstract class ForumMessages : System.Web.UI.UserControl
	{

		protected System.Web.UI.WebControls.Repeater messageList;
		protected System.Web.UI.WebControls.HyperLink lnkPrevious;
		protected System.Web.UI.WebControls.HyperLink lnkNext;
		
		protected System.Web.UI.WebControls.Label hdnFormForumID;
		
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedIn;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedOut;

		int forumID;
		
		// page variables
		private int currentPage = 0;
		private int pageCount = 0;
		private int numResults = 0;
		
		//display appriopriate folder (popular thread vs. normal thread image)
		public string IsHot(string szReplies)
		{
			if (szReplies != "")
			{
				if ((Int32.Parse(szReplies) < 10)) 
					return "0.gif";
				else
					return "1.gif";
			}
				// NULL and/or 0 Replies
			else
			{
				return "0.gif";
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			
			if(!IsPostBack)
			{
				// First time here we want to fetch the first page. All of the
				// other page requests will be handled through the page 
				// navigation button event handlers.
				currentPage = 1;
				BindPagedData();	
				ShowLoggedInArea();
								
			}
			
		}

		private void BindPagedData()
		{
			if (Request.QueryString["forumID"] !=null)
			{
				forumID = Int32.Parse(Request["forumID"]);
			
				hdnFormForumID.Text = "<input type=hidden name=forumID value=" + forumID + ">";

								
				// pull the values off the query string
				if (Request.QueryString["requestedPage"] != null) 
				{
					currentPage = System.Int32.Parse(Request.QueryString["requestedPage"]);
					pageCount = System.Int32.Parse(Request.QueryString["pageCount"]);
				}
				else
					currentPage = 1;

				CSF.ForumsDB messages = new CSF.ForumsDB();
         
				messageList.DataSource = messages.GetForumMessagesByPage(forumID, currentPage, CSF.Constants.FORUM_MESSAGES_PAGESIZE, ref numResults);
				messageList.DataBind();
				
				// if this is the first time, calculate the total number of pages
				if (!Page.IsPostBack) 
					pageCount = (int)System.Math.Ceiling((double)numResults / CSF.Constants.FORUM_MESSAGES_PAGESIZE);
			
				// hide or show navigation buttons
				if (pageCount > 1) 
				{
					// there are multiple pages
					lnkPrevious.Visible = currentPage > 1;
					lnkNext.Visible = currentPage < pageCount;
					lnkPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/forums/messages.aspx?forumID=" + forumID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					lnkNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/forums/messages.aspx?forumID=" + forumID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
				}
				else 
				{
					// there is only one page, hide both buttons
					lnkPrevious.Visible = lnkNext.Visible = false;
					lnkPrevious.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/forums/messages.aspx?forumID=" + forumID + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
					lnkNext.NavigateUrl = CSF.Constants.ROOT_URL + "/Members/Main/forums/messages.aspx?forumID=" + forumID + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
				}
				
								
			}
		}
		
		// New Message
		public void AddMessageBtn_Click(Object sender, EventArgs e)
		{
			if(Page.IsValid == true) 
			{
				
				
				if ((Page.User.Identity.IsAuthenticated) && (Request.QueryString["forumID"] !=null))
				{
					forumID =  Int32.Parse(Request["forumID"]);
					string NewTopic = (string)(Request["newTopic"]);
					string NewMessage = (string)(Request["NewMessage"]);
				
					CSF.ForumsDB message = new CSF.ForumsDB();
					message.PutForumMessage(Int32.Parse(Page.User.Identity.Name),forumID,Server.HtmlEncode(NewTopic),Server.HtmlEncode(NewMessage), CSF.Constants.PTS_FORUM_POST);

					//Response.Redirect("Messages.aspx?forumID=" + forumID);
					// return user back to same page, forum etc
					Response.Redirect(Request.RawUrl);
				}
			}
		
		}
		
		// display different items if person is logged in or not
		private void ShowLoggedInArea()
		{
			// check to see if we have a sessionid(formsAuthentication)
			bool loggedIn = false;
			
			if (Page.User.Identity.IsAuthenticated)
			{
				loggedIn = (Page.User.Identity.Name != null) ? true : false;
				
			}

			// show or hide login buttons
			areaLoggedIn.Visible = loggedIn ? true : false;
			areaLoggedOut.Visible = loggedIn ? false : true;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
