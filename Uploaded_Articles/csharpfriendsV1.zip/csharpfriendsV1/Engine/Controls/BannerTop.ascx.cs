namespace CSF.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Web.UI;

	/// <summary>
	///		Summary description for BannerTop.
	/// </summary>
	public abstract class BannerTop : System.Web.UI.UserControl
	{
//		protected System.Web.UI.WebControls.AdRotator adBannerTop;

		bool IsFlashAd = false;

		string strCustomFlashAd = @"<p>test custom output</p>";


//		OnAdCreated="AdCreated_Event"   <-- removed event from  the asp:adRotator tag
		

		private void Page_Load(object sender, System.EventArgs e)
		{
			
		}

		public void AdCreated_Event(Object sender, AdCreatedEventArgs e)
		{
			// modified tag of advertisment XML to ahve a flag for Flash banners,
			// if its set, set the boolean IsFlashAd to true
			if ("" != (string)e.AdProperties["flash"])
			{
				//Response.Write("booha!");
				IsFlashAd = true;
			}

		}

		// if this is a flash ad ie. IsFlashAd=true then display custom output
		protected override void Render(HtmlTextWriter output)
		{
			if (IsFlashAd)
			{
				output.Write( strCustomFlashAd );
			}
			else
			{
				base.Render(output);
			}
			
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
