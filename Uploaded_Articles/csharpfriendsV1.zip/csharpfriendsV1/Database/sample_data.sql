--insert users
procAddUserAndInfo 'admin', 'firstname', 'lastname', 'email', 'admin', '25', 'PHD', 'Canada', 'Developer', 'C#',
			'C#','PIII 800mhz', 1, 'hello world!'

update tblUserExt
	set IsConfirmed=1

--insert forum data
insert tblForums (szName, szDescription, iDisplayOrder)
values ('Test Forum', 'this is a test forum', 1)

procPutForumMessage 999, 1, 'test post', 'this is a test message!', 1


--tutorials
insert tblTutorialText(iTutorialID, szText, szTitle, szDescription, szIndex, userID)
values (1, 'This is a sample content page, nothing interesting to see here', 'Test Content Page', 'Here is a sample content page for your pleasure','S',999)

-- channels
insert tblChannels (szChannelName)
values ('sample channel section')

insert tblChannelArticles(channelID, szIcon, szTitle, szDescription, szFile, bFeature, userID)
values (1, '','sample article', 'sample article for your pleasure', 'sampleArticle',1,999)

--
insert tblQuestions ( title, description,userID)
values ('ComputerJobs.com and .Net', 'ComputerJobs.com fires up job searches four times faster, saves money with Visual Studio .NET...<a href="http://www.microsoft.com/resources/casestudies/CaseStudy.asp?CaseStudyID=13392" target="_blank">[read more]</a>', 999)