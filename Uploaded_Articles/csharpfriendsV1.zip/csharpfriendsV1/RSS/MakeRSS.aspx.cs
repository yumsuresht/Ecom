using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ASPAlliance.BLL;

namespace ASPAlliance.Pages.admin
{
	/// <summary>
	/// Summary description for MakeRSS.
	/// </summary>
	public class MakeRSS : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnUpdate;
		protected System.Web.UI.WebControls.Label lblResult; 

		public MakeRSS()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			Server.ScriptTimeout = 300;
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnUpdate_Click(object sender, System.EventArgs e)
		{
			ASPAlliance.BLL.RSS rss = new ASPAlliance.BLL.RSS();
			string sSiteTitle,sSiteDescr,sSiteURL,sSiteDetails,sImageURL,sFurtherReading,sAuthorNames,sAuthorEmails;
			string sTitle,sDescr,sURL,sDate,sCategory,sKeywords,sXMLFile;

			sSiteTitle = "CSharpFriends";
			sSiteDescr = "World's Greatest C# Community Site, FREE monthly prizes!";
			sSiteURL = "http://csharpfriends.com";
			sSiteDetails = "CSharpFriends.com";
			sImageURL = "http://www.csharpfriends.com/Members/images/logocc.gif";
			sFurtherReading = ""; // this should be a URL
			sAuthorNames = "Salman Ahmed";
			sAuthorEmails = System.Configuration.ConfigurationSettings.AppSettings["AdminEmail"];

			if(!rss.RSSheader(sSiteTitle, sSiteDescr, sSiteURL, sSiteDetails, sImageURL, sFurtherReading, sAuthorNames, sAuthorEmails))
			{
				lblResult.Text = "There was an error creating the header.";
				Response.End();
			}

			// Get list of articles
			CSF.TutorialsDB tutorials = new CSF.TutorialsDB();

			SqlDataReader dr = tutorials.GetAll();

			while(dr.Read())
			{
				// Required Elements
				sTitle = dr["szTitle"].ToString().Replace("&amp;","&").Replace("&","&amp;");
				sDescr = dr["szDescription"].ToString().Replace("&amp;","&").Replace("&","&amp;");
				sURL = @"http://www.csharpfriends.com/Members/Main/Tutorials/get_tutorial.aspx?tutID=" + dr["iTutorialID"].ToString();

				// all following elements are optional
				sDate = dr["dtCreated"].ToString();
				sCategory = "Articles";
				sKeywords = dr["szTitle"].ToString().Replace("&amp;","&").Replace("&","&amp;");

				// separate multiple authors with |
				// overrides authors passed to RSSheader
				//sAuthorNames = dr["first_name"].ToString() + " " + dr["last_name"].ToString();
				//sAuthorEmails = BLL.Columnist.getColumnist(Int32.Parse(dr["columnist_id"].ToString())).User.email;

				if(!rss.RSSitem(sTitle, sDescr, sURL, sDate, sCategory, sKeywords, sAuthorNames, sAuthorEmails))
				{
					lblResult.Text = "There was an error creating an item in the articles listing.";	
					Response.End();
				}
			}

			if(!rss.RSSfooter())
			{
				lblResult.Text = "There was an error creating the XML document footer.";
				Response.End();
			}


			// in this case we will write the XML to the file RSS.XML
			// but you could instead output the global variable 
			// sRSSXML to the client
			sXMLFile = "../RSS.xml";

			if(!rss.RSSpersist(sXMLFile))
			{
				lblResult.Text = "There was an error writing the XML file.";
				Response.End();
			}
	
			Response.Redirect(sXMLFile,true);
		}
	}
}
