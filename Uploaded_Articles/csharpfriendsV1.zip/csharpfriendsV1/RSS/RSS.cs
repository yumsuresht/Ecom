using System;
using System.Text;
using System.Web;

namespace ASPAlliance.BLL
{
	/// <summary>
	/// Summary description for RSS.
	/// </summary>
	public class RSS
	{
		private StringBuilder sbRSSXML;
		private StringBuilder sbItems;

		/// <summary>
		/// Constructor
		/// </summary>
		public RSS()
		{
			sbRSSXML = new StringBuilder();
			sbItems = new StringBuilder();
		}

		/// <summary>
		/// add the header to sRSSXML
		///
		/// The following parameters are mandatory:
		///  sSiteTitle, sSiteDescr, sSiteURL
		///
		/// The following parameters are optional:
		///  sSiteDetails, sImageURL, sAuthorNames, sAuthorEmails
		///  sFurtherReading
		///
		/// Note: sAuthorNames, sAuthorEmails and sFurtherReading can contain 
		///  multiple entries, separated by |. 
		///
		/// Both sAuthorNames and sAuthorEmails *must* have the same 
		///  number of  elements, but elements can be empty if required.
		/// </summary>
		/// <param name="sSiteTitle"></param>
		/// <param name="sSiteDescr"></param>
		/// <param name="sSiteURL"></param>
		/// <param name="sSiteDetails"></param>
		/// <param name="sImageURL"></param>
		/// <param name="sFurtherReading"></param>
		/// <param name="sAuthorNames"></param>
		/// <param name="sAuthorEmails"></param>
		/// <returns></returns>
		public bool RSSheader(string sSiteTitle, string sSiteDescr, string sSiteURL, 
			string sSiteDetails, string sImageURL, 
			string sFurtherReading, string sAuthorNames, 
			string sAuthorEmails)
		{
			// Check parameters
			if(sSiteTitle.Length==0)
			{
				throw(new ArgumentNullException("sSiteTitle","sSiteTitle is required."));
			}
			if(sSiteDescr.Length==0)
			{
				throw(new ArgumentNullException("sSiteDescr","sSiteDescr is required."));
			}
			if(sSiteURL.Length==0)
			{
				throw(new ArgumentNullException("sSiteURL","sSiteURL is required."));
			}

			// add header to XML string
			sbRSSXML.Append("<?xml version=\"1.0\"?>");

			sbRSSXML.Append("<rdf:RDF" + "\n");
	
			// specify namespaces
			sbRSSXML.Append(" xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"" + "\n");
			sbRSSXML.Append(" xmlns:dc=\"http://purl.org/dc/elements/1.1/\"" + "\n");
			sbRSSXML.Append(" xmlns:fr=\"http://ASPRSS.com/fr.html\"" + "\n");
			sbRSSXML.Append(" xmlns:pa=\"http://ASPRSS.com/pa.html\"" + "\n");
			sbRSSXML.Append(" xmlns=\"http://purl.org/rss/1.0/\">" + "\n");

			// specify channel
			sbRSSXML.Append("<channel rdf:about=\"" + sSiteURL + "\">");

			if(!RSStag("title", sSiteTitle))
			{
				return false;
			}
			if(!RSStag("link",sSiteURL))
			{
				return false;
			}
			if(!RSStag("description",sSiteDescr))
			{
				return false;
			}
			if(sSiteDetails.Length > 0)
			{
				if(!RSStag("dc:publisher",sSiteDetails))
				{
					return false;
				}
			}
			
			if(sFurtherReading.Length>0)
			{
				if(!RSStag("fr:url",sFurtherReading))
				{
					return false;
				}
			}

			if(sAuthorNames.Length>0)
			{
				if(!RSSauthor(sAuthorNames,sAuthorEmails))
				{
					return false;
				}
			}

			if(sImageURL.Length>0)
			{
				sbRSSXML.Append("<image rdf:resource=\"" + sImageURL + "\" />");
			}
		
			// add empty <items>, filled in later by RSSfooter()
			if(!RSStag("items",""))
			{
				return false;
			}

			// close channel
			sbRSSXML.Append("</channel>");

			// add optional image
			if(sImageURL.Length>0)
			{
				sbRSSXML.Append("<image rdf:about=\"" + sImageURL + "\">");

				if(!RSStag("title",sSiteTitle))
				{
					return false;
				}

				if(!RSStag("url",sImageURL))
				{
					return false;
				}

				if(!RSStag("link",sSiteURL))
				{
					return false;
				}
				sbRSSXML.Append("</image>");
			}
			return true;
		}

		/// <summary>
		/// add items to sRSSXML
		///
		/// The following parameters are mandatory:
		///  sTitle, sDescr, sURL
		///
		/// The following parameters are optional:
		///  sDate, sCategory, sKeywords, sAuthorNames, sAuthorEmails
		///
		/// Note: sAuthorNames and sAuthorEmails can contain multiple entries, 
		///  separated by |. Both *must* have the same number of  elements,
		///  but elements can be empty if required.
		/// 
		/// sKeywords can contain multiple keywords, but all will be grouped
		///  in a single element. Keywords should be seperated by commas.
		/// </summary>
		/// <param name="sTitle"></param>
		/// <param name="sDescr"></param>
		/// <param name="sURL"></param>
		/// <param name="sDate"></param>
		/// <param name="sCategory"></param>
		/// <param name="sKeywords"></param>
		/// <param name="sAuthorNames"></param>
		/// <param name="sAuthorEmails"></param>
		/// <returns></returns>
		public bool RSSitem (string sTitle, string sDescr, 
			string sURL, string sDate, 
			string sCategory, string sKeywords, 
			string sAuthorNames, string sAuthorEmails ) 
		{
			DateTime dDate;
			string sMonth;
			string sDay;
			string sValidDate;
			
			// Check parameters
			if(sTitle.Length==0)
			{
				throw(new ArgumentNullException("sTitle","sTitle is required."));
			}
			if(sDescr.Length==0)
			{
				throw(new ArgumentNullException("sDescr","sDescr is required."));
			}
			if(sURL.Length==0)
			{
				throw(new ArgumentNullException("sURL","sURL is required."));
			}

			// start new <resource>
			sbRSSXML.Append("<item rdf:about=\"" + sURL + "\">");
			if(!RSStag("title",sTitle))
			{
				return false;
			}
			if(!RSStag("description",sDescr))
			{
				return false;
			}
			if(!RSStag("link",sURL))
			{
				return false;
			}

			if(sDate.Length>0)
			{
				// make it a valid date according to 
				// http://www.w3.org/TR/NOTE-datetime

				// get a date object
				dDate = DateTime.Parse ( sDate );

				// make sure month is 2 digits
				sMonth = dDate.Month.ToString().PadLeft(2,'0');

				// make sure day is 2 digits
				sDay = dDate.Day.ToString().PadLeft(2,'0');

				// make valid date
				sValidDate = dDate.Year + "-" + sMonth + "-" + sDay;

				if(!RSStag("dc:date",sValidDate))
				{
					return false;
				}
			}

			if(sKeywords.Length > 0)
			{
				if(!RSStag("pa:keywords",sKeywords))
				{
					return false;
				}
			}

			if(sAuthorNames.Length > 0)
			{
				if(!RSSauthor(sAuthorNames,sAuthorEmails))
				{
					return false;
				}
			}

			// add to <items> store
			sbItems.Append("<rdf:li rdf:resource=\"" + sURL + "\" />\n");
			sbRSSXML.Append("</item>");
			return true;
		}

		
		
		/// <summary>
		/// add the footer to sRSSXML
		/// </summary>
		/// <returns></returns>
		public bool RSSfooter()
		{
			sbRSSXML.Append("</rdf:RDF>");

			string sBody = sbRSSXML.ToString();
			// fill in <items> element
			if(sBody.IndexOf("</items>",0) == 0)
			{
				throw(new Exception("Missing <items> element."));
			}
			sBody.Insert(sBody.IndexOf("</items>",0),"<rdf:Seq>\n" + sbItems.ToString() + "</rdf:Seq>\n");
			sbRSSXML = new StringBuilder(sBody);
			return true;
		}


		
		/// <summary>
		/// writes sRSSXML to file
		///
		/// The following parameters are mandatory:
		///  sFilename
		///
		/// note: requires write permission to file sFilename
		/// </summary>
		/// <param name="sFilename"></param>
		/// <returns></returns>
		public bool RSSpersist(string sFilename)
		{			
			System.IO.StreamWriter sw = System.IO.File.CreateText(HttpContext.Current.Server.MapPath(sFilename));
			sw.Write(sbRSSXML.ToString());
			sw.Close();
			return true;
		}
		
		/// <summary>
		/// store tag + value
		///
		/// The following parameters are mandatory:
		///  sTag, sValue
		/// </summary>
		/// <param name="sTag"></param>
		/// <param name="sValue"></param>
		/// <returns></returns>
		private bool RSStag(string sTag, string sValue)
		{
			System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex("<[^>]*>",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
			string sStripped = reg.Replace(sValue,"");

			sbRSSXML.Append("<" + sTag + ">" + sStripped + "</" + sTag + ">\n");

			return true;
		}
		
		/// <summary>
		/// store authors in <dc:creator>'s
		///
		/// The following parameters are mandatory:
		///  sAuthorNames, sAuthorEmails
		///
		/// note: sName and sEmail *must* have the same number of  elements
		/// </summary>
		/// <param name="sAuthorNames"></param>
		/// <param name="sAuthorEmails"></param>
		/// <returns></returns>
		private bool RSSauthor(string sAuthorNames, string sAuthorEmails)
		{

			string[] sNames, sEmails;
			string sName, sEmail;
			int i;

			sNames = sAuthorNames.Split('|');
			sEmails = sAuthorEmails.Split('|');
			
			if(sNames.GetUpperBound(0) != sEmails.GetUpperBound(0))
			{
				throw(new ArgumentOutOfRangeException("sAuthorEmails",sAuthorEmails,"Number of emails must match number of author names."));
			}

			for(i=0;i<=sNames.GetUpperBound(0);i++)
			{
				sbRSSXML.Append("<dc:creator>");
				sName = sNames[i];
				sEmail = sEmails[i];

				// add spaces and braces if both specified
				if(sName.Length > 0)
				{
					if(sEmail.Length > 0)
					{
						sbRSSXML.Append(sName + " (mailto:" + sEmail + ")");
					}
					else
					{
						sbRSSXML.Append(sName);
					}
				}
				else
				{
					sbRSSXML.Append("mailto:" + sEmail);
				}

				sbRSSXML.Append("</dc:creator>");
			}
			return true;
		}
	
	}
}
